import React, { Component } from 'react';
class BatchInfoButtonHeader extends Component {
    render() {
        return (
            
                <table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#0066ce" className="BatchInfoButtonHeader">
                    <tr>
                        <td>
                            <table width="64" border="0" cellpadding="0" cellspacing="0">
                                <tr>
                                    <td width="8" height="22" bgcolor="#0066ce"></td>
                                    <td width="54" height="22" bgcolor="#0066ce"></td>
                                </tr>
                            </table>
                        </td>
                        <td>
                            <table align="right" border="0" cellpadding="0" cellspacing="0">
                                <tr>
                                    <td bgcolor="#0066ce" width="8" height="22"></td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>
                

        );
    }
}

export default BatchInfoButtonHeader;
