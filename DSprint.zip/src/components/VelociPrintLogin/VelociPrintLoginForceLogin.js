import React, { Component } from 'react';

class VelociPrintLoginForceLogin extends Component {
    render() {
        return (
            <tr className="body">
                <td width="20%" colSpan="1" height="24" align="left">&nbsp;</td>
                <td width="30%" colSpan="1" height="24" align="left">Force Login</td>
                <td width="50%" colSpan="1" height="24" align="left">
                    <input type="checkbox" name="Flogin" />
                </td>
            </tr>
        );
    }
}

export default VelociPrintLoginForceLogin;
