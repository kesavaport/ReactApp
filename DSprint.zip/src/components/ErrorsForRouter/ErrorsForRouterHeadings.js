import React, { Component } from 'react';

class ErrorsForRouterHeadings extends Component {
    render() {
        return (
            <tr className="HeadTable">
                <td width="5%" colSpan="1" height="21" align="center">
                    <input type="checkbox" name="chkBox" />
                </td>
                <td width="17%" colSpan="1" height="21" align="left">Batch Name</td>
                <td width="12%" colSpan="1" height="21" align="left">Batch Date</td>
                <td width="20%" colSpan="1" height="21" align="left">Email</td>
                <td width="13%" colSpan="1" height="21" align="left">Fax</td>
                <td width="33%" colSpan="1" height="21" align="left">Exception</td>
            </tr>

        );
    }
}

export default ErrorsForRouterHeadings;
