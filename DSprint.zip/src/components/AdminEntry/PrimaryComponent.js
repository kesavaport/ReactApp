import React, { Component } from 'react';
import Dashboard from './Dashboard'
import Username from './Username'
import Password from './Password'
import ConfirmPassword from './ConfirmPassword'
import LoginCancel from './LoginCancel'
import CssComponent from './CssComponent'

class PrimaryComponent extends Component {
  render() {
    return (
    <div className="PrimaryComponent">
       <Dashboard />
       <Username />
       <Password />
       <ConfirmPassword />
       <LoginCancel />
       <CssComponent />
    </div>
    );
  }
}

export default PrimaryComponent;