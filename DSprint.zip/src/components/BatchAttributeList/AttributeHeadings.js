import React, { Component } from 'react';

class AttributeHeadings extends Component {
    render() {
        return (
            <tr className="HeadTable HeadBold AttributeHeadings">
                <td width="10%" colSpan="1" height="21" align="center">Select</td>
                <td width="40%" colSpan="1" height="21" align="left">Attribute Name</td>
                <td width="50%" colSpan="1" height="21" align="left">Attribute Description</td>
            </tr>
        );
    }
}
export default AttributeHeadings;