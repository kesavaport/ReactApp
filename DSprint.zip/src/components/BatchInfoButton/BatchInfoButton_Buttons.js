import React, { Component } from 'react';
import BatchInfo from '../BatchInfo';
import {Link} from 'react-router-dom';
class BatchInfoButton_Buttons extends Component {
    render() {
        return (
            
       
                <form className="BatchInfoButton_Buttons">
                    <br />
                    <br />
                    <table cellSpacing="0" cellPadding="0" width="100%" align="center" border="0">
                        <tbody>
                            <tr>
                                <td width="100%" colSpan="3" align="center" >
                                    <Link to="BatchInfo"><input type="button" name="Update" value="Update" className="btn btn-primary" /></Link>&nbsp;
                                    <Link to="BatchInfo"><input type="button" name="Delete" value="Delete" className="btn btn-primary" /></Link>&nbsp;
                                    <Link to="BatchInfo"><input type="button" name="Add" value="Add" className="btn btn-primary" /></Link>&nbsp;
                               </td>
                            </tr>
                        </tbody>
                    </table>
                </form>

        );
    }
}

export default BatchInfoButton_Buttons;
