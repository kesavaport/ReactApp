import React, { Component } from 'react';

class SeachType extends Component {
    render() {
        return (
            <tr className="body">
                <td width="20%" colSpan="1" height="21" align="left">&nbsp;&nbsp; Select Search Type</td>
                <td width="40%" colSpan="1" height="21" align="left">&nbsp;
                     <input type="radio" name="Document" value="DocSet" size="15" className="inps" />DocSet
                     <input type="radio" name="Document" value="Document" size="15" className="inps" /> Document
                 <br />
                </td>
                <td width="100%" colSpan="3" height="21">&nbsp;</td>
            </tr>


        );
    }
}

export default SeachType;
