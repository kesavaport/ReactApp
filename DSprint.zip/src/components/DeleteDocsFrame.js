import React, { Component } from 'react';
class DeleteDocsFrame extends Component {
    render() {
        return (
            <div className="DeleteDocsFrame">
                <frameset rows="*,70" cols="*" framespacing="0" border="0">
                    {/* <frame src="jsp/dsprint/ListBatchForDeleteDocs.do" name="FRAME_PRINT_TOP" frameborder="0" scrolling="auto"> */}
                    <frame src="DeleteDocsButton.html" name="FRAME_PRINT_BOTTOM" frameborder="0" scrolling="no" />
                </frameset>

            </div>
        );
    }
}

export default DeleteDocsFrame;
