import React, { Component } from 'react';
import BatchInfoButtonHeader from './BatchInfoButton/BatchInfoButtonHeader';
import BatchInfoButton_Buttons from './BatchInfoButton/BatchInfoButton_Buttons';

class BatchInfoButton extends Component {
    render() {
        return (
            <div className="BatchInfoButton">
                <BatchInfoButtonHeader />
                <BatchInfoButton_Buttons />

            </div>
        );
    }
}

export default BatchInfoButton;
