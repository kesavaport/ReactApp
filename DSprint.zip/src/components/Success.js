import React, { Component } from 'react';

class Success extends Component {
    render() {
        return (
            <div className="body">
                <script language="JavaScript">
                    {alert("Batch Created Successfully")};
            </script>
            </div>
        );
    }
}

export default Success;
