import React from "react";
import {Card,  CardHeader, CardText} from 'material-ui/Card';
import TextField from 'material-ui/TextField';
import RaisedButton from 'material-ui/RaisedButton';
import DropDownMenu from 'material-ui/DropDownMenu';
import MenuItem from 'material-ui/MenuItem';

const styles={
    hold:{
        width:"550px",
        margin:"20px auto"
    },
    fullWidth:{
        width:"100%"
    },
    commentStyle:{
        background:"#3f51b5",
        borderRadius:"2px",
        padding:"10px",
        margin:"5px",
        color:"#fff"

    },
    postCommentsHold:{
        marginTop:"20px"
    },
    comment:{
        margin:0,cursor:"pointer"
    },
    commentMessage:{transition:"0.1s",display:"block",background:"#fff",margin:"10px auto 0",color:"#000",paddingLeft:"5px"},
    hideMessage:{display:"none",transition:"0.1s"},
    dateBadge:{
        borderRadius:"2px",
        background:"#fff",
        float:"right",
        color:"#000",
        padding:"1px 3px"
    }
   
}
const commentsAll=[
    {
        Activity:"Data Entry",
        User:"AWPL_user", 
        Date:"31/1/2018",
        Comment:"Message"
    },
    {
        Activity:"Data Entry",
        User:"AWPL_user", 
        Date:"2/2/2018",
        Comment:"Message"
    },  
    {
        Activity:"Data Verification",
        User:"AWPL_user", 
        Date:new Date().getDate()+"/"+new Date().getMonth()+"/"+new Date().getFullYear(),
        Comment:"Message"
    }
    
]
class RemarksComponent extends React.Component{
constructor(props){
    super(props)
    this.handlerPostComment=this.handlerPostComment.bind(this)
    this.handleChange=this.handleChange.bind(this)
    this.state={value:1}
}
   
    handlerPostComment(message){
            this.child.setListOfComments(message)
            console.log(this.child)
    }
    handleChange = (event, index, value) =>{
        this.child.handlerchangedDropdown(value)
         return this.setState({value})
        };
    render(){
        return(
            <div className="remarkspage">
               <div className="mdl-cell mdl-cell--12-col">
                <Card style={styles.hold} className="">
                 <CardHeader title="Temporary Comments" className="cardHeaderRemarkspage mdl-color-text--blue" style={{background:"#3f51b5"}}>
                 <DropDownMenu value={this.state.value} onChange={this.handleChange} className="dropdownstyle" >
                    <MenuItem key={1} value={1} primaryText={"Activity"}> </MenuItem>
                    <MenuItem key={2} value={2} primaryText={"User"}> </MenuItem>
                    
                 </DropDownMenu>
                 </CardHeader>
                 <CardText className="mdl-color--light-grey-500" style={{background:"#efeee4"}}>
                    <CommentsContainerComponent onRef={ref => (this.child = ref)} />
                    <Card style={styles.postCommentsHold}>
                    <CardText  style={{padding:"5px"}}>
                        <PostCommentsComponent handlerPostComment={this.handlerPostComment}/>
                    </CardText>
                    </Card>
                 </CardText>

                </Card>
                
                </div>
               
            </div>
        );
    }
}
export default RemarksComponent;

class CommentsContainerComponent extends React.Component{
   

    constructor(props){
        super(props)
        this.state={
            listOfComments:commentsAll,
                user:false,
                activity:true
        }
        this.setListOfComments=this.setListOfComments.bind(this)
        this.handlerchangedDropdown=this.handlerchangedDropdown.bind(this)
    }
    componentDidMount() {
        this.props.onRef(this)
      }
      componentWillUnmount() {
        this.props.onRef(undefined)
      }
   setListOfComments(message){
       this.setState((previousState)=>{
           return {
            listOfComments:previousState.listOfComments.concat(this.newPost(message))
           }
       })
   }
   newPost(message){
    return {
        Activity:"Data Verification",
         User:"AWPL_user", 
         Date:new Date().getDate()+"/"+(parseInt(new Date().getMonth())+1)+"/"+new Date().getFullYear(),
         Comment:message
    }
}
handlerchangedDropdown(value){
    //this.child.handlerchangedDropdown(value)
    
    if(value===1){
       // console.log("activity");
    this.setState({activity:true,user:false})
    } 
     if(value===2){
       // console.log("user");
   // this.setState.activity=false;
   this.setState({activity:false,user:true})
    } 
}

    render(){
        return(
            <div>
                {this.state.listOfComments.map((item,index)=>{
                    return(
                       <div key={index}> 
                       { this.state.activity && <CommentComponent item={item } key={index} onRef={ref => (this.child = ref)}/>}
                       { this.state.user && <UserCommentComponent item={item } key={index} onRef={ref => (this.child2 = ref)}/>}
                       </div>
                    )
                })}
            </div>
        );
    }
}

class CommentComponent extends React.Component{
    constructor(props){
        super(props)
        this.handlerToggleShow=this.handlerToggleShow.bind(this);
        this.state={
            showActivity:styles.hideMessage,
            showUser:styles.hideMessage
        }
    }

    componentDidMount() {
        this.props.onRef(this)
      }
      componentWillUnmount() {
        this.props.onRef(undefined)
      }
    handlerToggleShow(){
        this.setState((previousState)=>{
          // console.log(this.state.activity)
            if((previousState.showActivity===styles.hideMessage) )
               return {showActivity:styles.commentMessage}
            if((previousState.showActivity===styles.commentMessage) )
            return {showActivity:styles.hideMessage }    
        });
    }

    render(){
        return(          
            <div style={styles.commentStyle}>

                <div style={{margin:0,padding:0}}>
                    <p style={styles.comment} onClick={this.handlerToggleShow}>  
                         {this.props.item.Activity} 
                         <span style={styles.dateBadge}>{this.props.item.Date}</span>
                    </p>
                    <p style={this.state.showActivity}>User:{this.props.item.User}<br/>Comment:{this.props.item.Comment}</p>
                </div>

            </div>
        )
    }
}

class UserCommentComponent extends React.Component{
    constructor(props){
        super(props)
        this.handlerToggleShow=this.handlerToggleShow.bind(this);
        this.state={
            showActivity:styles.hideMessage,
            showUser:styles.hideMessage
        }
    }

    componentDidMount() {
        this.props.onRef(this)
      }
      componentWillUnmount() {
        this.props.onRef(undefined)
      }
    handlerToggleShow(){
        this.setState((previousState)=>{
          console.log(this.state.activity)
            if((previousState.showUser===styles.hideMessage) )
               return {showUser:styles.commentMessage}
            if((previousState.showUser===styles.commentMessage) )
            return {showUser:styles.hideMessage }    
        });
    }

    render(){
        return(          
            <div style={styles.commentStyle}>

                <div style={{margin:0,padding:0}}>
                    <p style={styles.comment} onClick={this.handlerToggleShow}>  
                    User: {this.props.item.User} 
                         <span style={styles.dateBadge}>{this.props.item.Date}</span>
                    </p>
                    <p style={this.state.showUser}>Activity:{this.props.item.Activity}<br/>Comment:{this.props.item.Comment}</p>
                    
                </div>
          
            
            </div>
        )
    }
}

class PostCommentsComponent extends React.Component{
    constructor(props){
        super(props)
        this.handlerPostComment=this.handlerPostComment.bind(this);
    }
    handlerPostComment(event){
        event.preventDefault();
       
        //console.log("Post comments Handler")
        let message=event.target.querySelector("textarea[name=commentsToPost]").value;
        event.target.querySelector("textarea[name=commentsToPost]").value="";
        this.props.handlerPostComment(message);
    }
    render(){
        return(
            
            <form action="#" onSubmit={this.handlerPostComment}>
            <div className="mdl-grid"  style={{padding:0}}>
              <div className="mdl-cell mdl-cell--12-col mdl-cell--4-col-phone mdl-cell--8-col-tablet">
                    <TextField hintText="Enter the Comments here" multiLine={true} rows={1} rowsMax={2} style={styles.fullWidth} name="commentsToPost"/>
              </div>  
              </div> 
              <div className="mdl-grid"  style={{padding:0}}>
              <div className="mdl-cell mdl-cell--12-col mdl-cell--4-col-phone mdl-cell--8-col-tablet" style={{marginTop:0}}>
              
                        <RaisedButton  className="btnStyle"  type="submit">Add Comments</RaisedButton>
              
              </div>  
              </div> 
              </form>
               

        );
    }
}