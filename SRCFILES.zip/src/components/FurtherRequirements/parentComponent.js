import React, {Component} from "react";
import CaseRequirmentComponent from "./CaseRequirmentComponent";
import OutstandingReqComponent from "./OutstandingReqComponent";
import { connect } from 'react-redux';
import { updateCaseReq, updateOutReq } from '../../actions/action';

export class ParentComponent extends React.Component{
  constructor(props){
    super(props)
    this.updateCaseReq=this.updateCaseReq.bind(this);
    this.updateOutReq=this.updateOutReq.bind(this);    
  }

  updateCaseReq(index){
    this.props.updateCaseReq(index)
    //this.forceUpdate()
  }

  updateOutReq(index){
    this.props.updateOutReq(index)
    //this.forceUpdate()
  }

    render(){
        return(
            <div>
              <div className="row" style={{color:"#000"}}>
              <div className="col s12 m6">
                    <CaseRequirmentComponent caseReq={this.props.requirements.caseReq} updateCaseReq={this.updateCaseReq} />
                 </div> 
              <div className="col s12 m6">     
                <OutstandingReqComponent outReq={this.props.requirements.outReq} updateOutReq={this.updateOutReq} />
              </div>  
              </div>  
            </div>
        )
    }
}

//export default ParentComponent;


// AppContainer.js
const mapStateToProps = (state, ownProps) => ({
  requirements: state.requirements,
  });
  
  const mapDispatchToProps = {
    updateCaseReq,
    updateOutReq
  };
  
  const AppContainer = connect(
    mapStateToProps,
    mapDispatchToProps
  )(ParentComponent);
  
  export default AppContainer;
  
  