import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import Printer from '../Printer';
import ErrorDocumentsForPrint from '../ErrorDocumentsForPrint';
class ErrorDocForPrintButton extends Component {
    render() {
        return (
            <tr>
                <td width="100%" colSpan="7" align="center">
                    <Link to="/ErrorDocumentsForPrint"><input type="button" className="btn btn-primary" name="Listdoc" value="List Documents" /></Link>&nbsp;
                    <Link to="/Printer"> <input type="button" className="btn btn-primary" name="Print" value="Print" /></Link>
                </td>
                
            </tr>

        );
    }
}

export default ErrorDocForPrintButton;
