import React, { Component } from 'react';
import AppRouter from './routers/AppRouter';
import logo from './logo.svg';
import './App.css';
import './css/style.css';
import './css/buttonStyle.css';

class App extends Component {
  render() {
    return (
      <div className="App">
        
       <div>
       <AppRouter />
       </div> 
   </div>
    );
  }
}
export default App;

