import React, { Component } from 'react';

class UserInfoEntryConfirmPassword extends Component {
    render() {
        return (
            <tr className="body">
                <td width="20%" colSpan="1" height="21" align="left">&nbsp;Confirm Password</td>

                <td width="40%" colSpan="1" height="21" align="left">&nbsp;
                <input type="password" id="confirmPassword" size="15" style={{ border: "" }} className="inps" /></td>
                <td width="40%" colSpan="1" height="21" align="left"></td>
            </tr>

        );
    }
}

export default UserInfoEntryConfirmPassword;
