import React, { Component } from 'react';
import DCLComponent from './DecisionChecklist';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';

export class DecisionChecklistComponent extends Component {

    render() {
        // console.log(this.props.geod)
        return (
            <MuiThemeProvider>
                <DCLComponent />
            </MuiThemeProvider >
        )
    }
}
//export default DecisionChecklistComponent;