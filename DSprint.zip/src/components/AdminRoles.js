import React, { Component } from 'react';
import AdminRolesHeader from './AdminRoles/AdminRolesHeader';
import AdminRolesBatchAttributes from './AdminRoles/AdminRolesBatchAttributes';
import AdminRolesBatches from './AdminRoles/AdminRolesBatches';
import AdminRolesUsers from './AdminRoles/AdminRolesUsers';
import AdminRolesBatchAllocation from './AdminRoles/AdminRolesBatchAllocation';

class AdminRoles extends Component {
    render() {
        return (
            <div className="AdminRoles">
                <AdminRolesHeader />


                <table cellSpacing="0" cellPadding="0" align="center" width="100%" border="0" >
                    <tbody>
                        <tr><td height="35" width="100">&nbsp;</td></tr>
                        <AdminRolesBatchAttributes />
                        <AdminRolesBatches />
                        <AdminRolesUsers />
                        <AdminRolesBatchAllocation />
                    </tbody>
                </table>

            </div>
        );
    }
}

export default AdminRoles;
