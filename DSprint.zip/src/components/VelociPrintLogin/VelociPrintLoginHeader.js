import React, { Component } from 'react';

class VelociPrintLoginHeader extends Component {
    render() {
        return (
            <tr>
                <td width="1" className="body" width="1" height="23" bgcolor="#0066ce"></td>
                <td width="102%" bgcolor="0066ce" colSpan="3" align="center" className="HeadBold">DotSphere Print Login</td>
                <td width="1" height="23" bgcolor="#0066ce"></td>
            </tr>
        );
    }
}

export default VelociPrintLoginHeader;
