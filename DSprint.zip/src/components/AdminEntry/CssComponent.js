import React, { Component } from 'react';

class CssComponent extends Component {
  render() {
    return (
      <div className="CssComponent">
        <table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#0066ce">
          <tr>
            <td>
              <table width="64" border="0" cellpadding="0" cellspacing="0">
                <tr>
                  <td width="8" height="22" bgcolor="#0066ce"></td>
                  <td width="54" height="22" bgcolor="#0066ce"></td>
                </tr>
              </table>
            </td>
            <td>
              <table align="right" border="0" cellpadding="0" cellspacing="0">
                <tr>
                  <td bgcolor="#0066ce" width="8" height="22"></td>
                </tr>
              </table>
            </td>
          </tr>
        </table>

        <table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="1" height="1"><img src="images/ImagesHeader/spacer.gif" width="1" height="1" /> </td>
          </tr>
        </table>

        <table width="100%" border="0" cellpadding="0" cellspacing="0" background="Dotsphere.gif">
          <tr>
            <td width="257">&nbsp;</td>
            <td bgcolor="#FFFFFF" align="right">
              <table border="0" align="right" cellpadding="0" cellspacing="0">
                <tr >
                  <td bgcolor="#FFFFFF"><img src="images/ImagesHeader/spacer.gif" width="3" height="1" /></td>
                  <td><img src={require("images/dsPrint/DotSpherePrint_Logo.gif")} name="Image12" width="168" height="41" border="0" /></td>
                  <td><img src="images/ImagesHeader/spacer.gif" width="3" height="1" /></td>
                </tr>
              </table>
            </td>
          </tr>
        </table>
      </div>
    );
  }
}

export default CssComponent;
