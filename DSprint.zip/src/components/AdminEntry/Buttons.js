import React, { Component } from 'react';

class Buttons extends Component {
  render() {
    const { name , text } = this.props;
    return (
  
  
      
       <button 
       name={name}
       className="btn btn-primary"
      // Link to="/hello"
      // Link to="/hi"
       >{text} </button>	
     
  
    );
  }
}

export default Buttons;
