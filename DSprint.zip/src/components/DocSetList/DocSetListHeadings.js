import React, { Component } from 'react';

class DocSetListHeadings extends Component {
    render() {
        return (
            <tr className="HeadTable">
                <td width="10%" colSpan="1" height="21" align="center">
                    
                    <input type="checkbox" name="chkBox" disabled="disabled" />
                </td>
                <td width="15%" colSpan="1" height="21" align="left">DocSet ID</td>
                <td width="20%" colSpan="1" height="21" align="left">Batch Name</td>
                <td width="15%" colSpan="1" height="21" align="left">Batch Date</td>
                <td width="10%" colSpan="1" height="21" align="left">No. of Documents</td>
                <td width="15%" colSpan="1" height="21" align="left">No.of Copies</td>
                <td width="15%" colSpan="1" height="21" align="left">print Status</td>
            </tr>
        );
    }
}

export default DocSetListHeadings;
