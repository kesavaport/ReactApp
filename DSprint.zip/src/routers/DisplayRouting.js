import React, { Component } from 'react';
import ReactDOM from 'react-dom';

import AdminRouting from './AdminRouting';
import VPLoggedPage from '../components/VPLoggedPage';

class DisplayRouting extends Component {
    render() {
      return (
          <div className="DisplayRouting">
          <VPLoggedPage />
          <AdminRouting />
          </div>
      );
    }
  }
  
  export default DisplayRouting;