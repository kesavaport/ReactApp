import React, { Component } from 'react';
import PrinterNotFoundHeader from './PrinterNotFound/PrinterNotFoundHeader';
//import PrinterNotFoundHeader from './PrinterNotFound/PrinterNotFoundHeadings';
import PrinterNotFoundData from './PrinterNotFound/PrinterNotFoundData';
import PrinterNotFoundButton from './PrinterNotFound/PrinterNotFoundButton';

class PrinterNotFound extends Component {
    render() {
        return (
            <div className="container3">
                <form>
                    <br />
                    <br />
                    <table cellSpacing="0" cellPadding="0" width="100%" align="center" border="0">
                        <tbody>
                            <PrinterNotFoundHeader />
                            <tr>
                                <td width="1" bgColor="#0066ce">
                                    <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                                </td>
                                <td width="100%" colSpan="3">
                                    <br />
                                    <table cellSpacing="1" cellPadding="1" width="100%" align="center" border="0">
                                        <tbody>
                                            {/*=====PrinterNotFoundHeadings */}
                                            <td width="100%" colSpan="3">&nbsp;</td>
                                            <PrinterNotFoundData />
                                            <tr>
                                                <td width="100%" colSpan="3">&nbsp;</td>
                                            </tr>
                                            <PrinterNotFoundButton />
                                        </tbody>
                                    </table>
                                </td>
                                <td width="1" bgColor="#0066ce">
                                    <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                                </td>
                            </tr>
                            <tr>
                                <td width="1" bgColor="#0066ce">
                                    <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                                </td>
                                <td bgColor="#0066ce" colSpan="3">
                                    <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                                </td>
                                <td width="1" bgColor="#0066ce">
                                    <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </form>
            </div>
        );
    }
}

export default PrinterNotFound;
