import React, { Component } from 'react';
class AdminRightsFrame extends Component {
    render() {
        return (
               
                <frameset rows="*" cols="150,*" framespacing="0" border="0">
                    <frame src="./AdminRoles.js" name="FRAME_PRINT_LEFT" frameborder="0" scrolling="no" />
                        <frame src="" name="FRAME_PRINT_RIGHT" frameborder="0" scrolling="auto" /> 
                </frameset>

           
                    );
    }
}

export default AdminRightsFrame;
