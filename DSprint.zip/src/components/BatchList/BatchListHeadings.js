import React, { Component } from 'react';
class BatchListHeadings extends Component {
    render() {
        return (

            <tr className="HeadTable BatchListHeadings">
                <td width="10%" colSpan="1" height="21" align="center">Select</td>
                <td width="30%" colSpan="1" height="21" align="left">Batch Name</td>
                <td width="40%" colSpan="1" height="21" align="left">Batch Description</td>
                <td width="20%" colSpan="1" height="21" align="left">Attribute Count</td>
            </tr>

        );
    }
}

export default BatchListHeadings;
