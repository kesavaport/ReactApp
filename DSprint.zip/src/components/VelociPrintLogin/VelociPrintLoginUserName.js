import React, { Component } from 'react';

class VelociPrintLoginUserName extends Component {
    render() {
        return (
            <tr className="body">
                <td width="20%" colSpan="1" height="24" align="left">&nbsp;</td>
                <td width="30%" colSpan="1" height="24" align="left">Username</td>
                <td width="50%" colSpan="1" height="24" align="left">
                    <input type="text" size="15" style={{ border: "" }} />
                </td>
            </tr>
        );
    }
}

export default VelociPrintLoginUserName;
