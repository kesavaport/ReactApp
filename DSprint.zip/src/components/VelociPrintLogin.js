import React, { Component } from 'react';
import VelociPrintLoginHeader from './VelociPrintLogin/VelociPrintLoginHeader';
import VelociPrintLoginUserName from './VelociPrintLogin/VelociPrintLoginUserName';
import VelociPrintLoginPassword from './VelociPrintLogin/VelociPrintLoginPassword';
import VelociPrintLoginForceLogin from './VelociPrintLogin/VelociPrintLoginForceLogin';
import VelociPrintLoginButton from './VelociPrintLogin/VelociPrintLoginButton';
import VelociPrintLoginHeading from './VelociPrintLogin/VelociPrintLoginHeading';
import DotSpherePrintLogo from '../images/dsPrint/DotSpherePrint_Logo.gif'
import DotSphereLogo from '../Dotsphere.gif'
class VelociPrintLogin extends Component {
    render() {
        return (
            <div className="body">
            <table width="100%" border="0" cellPadding="0" cellSpacing="0" bgcolor="#0066ce">
            <tbody>
                <tr>
                    <td>
                        <table width="64" border="0" cellPadding="0" cellSpacing="0">
                        <tbody>
                            <tr>
                                <td width="8" height="22" bgcolor="#0066ce"></td>
                                <td width="54" height="22" bgcolor="#0066ce"></td>
                            </tr>
                        </tbody>
                        </table>
                    </td>
                    <td>
                        <table align="right" border="0" cellPadding="0" cellSpacing="0">
                        <tbody>
                            <tr>
                                <td bgcolor="#0066ce" width="8" height="22"></td>
                            </tr>
                        </tbody>
                        </table>
                    </td>
                </tr>
                </tbody>
            </table>
            <table width="100%" border="0" cellSpacing="0" cellPadding="0">
            <tbody>
                <tr>
                    <td width="1" height="1"><img src="images/ImagesHeader/spacer.gif" width="1" height="1"/></td>
                </tr>
            </tbody>
            </table>
            <table width="100%" border="0" cellPadding="0" cellSpacing="0" background={DotSphereLogo}>
            <tbody>
                <tr>
                    <td width="257">&nbsp;</td>
                    <td bgcolor="#FFFFFF" align="right">
                        <table border="0" align="right" cellPadding="0" cellSpacing="0">
                        <tbody>
                            <tr>
                                <td bgcolor="#FFFFFF"><img src="images/ImagesHeader/spacer.gif" width="3" height="1" /></td>
                                <td><img src={`${DotSpherePrintLogo}`} name="Image12" width="168" height="41" border="0" /></td>
                                <td><img src="images/ImagesHeader/spacer.gif" width="3" height="1" /></td>
                            </tr>
                        </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
            </table>
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <table cellSpacing="0" cellPadding="0" width="30%" align="center" border="0">
                <tbody>
                    <VelociPrintLoginHeader />
                    <tr>
                        <td width="1" bgcolor="#0066ce">
                            <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                        </td>
                        <td width="100%" colSpan="3">
                            <table cellSpacing="0" cellPadding="0" width="100%" align="center" border="0">
                                <tbody>
                                    <tr className="body">
                                        <td width="100%" colSpan="3" height="23">&nbsp;</td>
                                    </tr>
                                    <VelociPrintLoginHeading /> 
                                    <tr className="body">
                                        <td width="100%" colSpan="3" height="23">&nbsp;</td>
                                    </tr>
                                   
                                   <VelociPrintLoginUserName />
                                   <VelociPrintLoginPassword />
                                   <VelociPrintLoginForceLogin />
                                    <tr className="body">
                                        <td width="100%" colSpan="3" height="21">&nbsp;</td>
                                    </tr>
                                    <VelociPrintLoginButton />
                                    <tr className="body">
                                        <td width="100%" colSpan="3" height="23">&nbsp;</td>
                                    </tr>
                                    <tr x="body">
                                        <td width="100%" bgcolor="#0066ce" colSpan="4">
                                            <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </td>
                        <td width="1" bgcolor="#0066ce">
                            <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        );
    }
}

export default VelociPrintLogin;
