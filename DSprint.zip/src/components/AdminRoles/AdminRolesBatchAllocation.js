import React, { Component } from 'react';

class AdminRolesBatchAllocation extends Component {
  render() {
    return (
        <tr>
          <td height="35" width="100"> 
             <input type="button" name="batchAllo" value="Batch Allocation" className="btn btn-primary" />
          </td>
        </tr>
    );
  }
}

export default AdminRolesBatchAllocation;