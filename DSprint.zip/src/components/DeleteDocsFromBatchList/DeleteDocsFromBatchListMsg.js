import React, { Component } from 'react';

class DeleteDocsFromBatchListMsg extends Component {
  render() {
    return (
        <tr className="body">
        <td width="100%" colSpan="4" height="21" align="center" className="HeadBold">NoRecFound</td>
    </tr>
    );
  }
}

export default DeleteDocsFromBatchListMsg;