import React, { Component } from 'react';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import RemarkComponent from './RemarkComponent';

export class RemarksComponent extends Component {

    render() {
        // console.log(this.props.geod)
        return (
            <MuiThemeProvider>

                <RemarkComponent />
            </MuiThemeProvider>
        )
    }
}
//export default RemarksComponent;