import React, { Component } from 'react';

class DocumentListMsg extends Component {
    render() {
        return (
            <tr className="body ">
                <td width="100% " colSpan="9 " height="21 " align="center " className="HeadBold ">noRecord!...</td>
            </tr>
        );
    }
}

export default DocumentListMsg;
