import React, { Component } from 'react';
import VPLoggedPage from './VPLoggedPage';
import ErrorDocumentsForPrintHeader from './ErrorDocumentsForPrint/ErrorDocumentsForPrintHeader';
import ErrorDocumentsForPrintHeadings from './ErrorDocumentsForPrint/ErrorDocumentsForPrintHeadings';
import ErrorDocumentsForPrintData from './ErrorDocumentsForPrint/ErrorDocumentsForPrintData';
import ErrorDocumentsForPrintButton from './ErrorDocumentsForPrint/ErrorDocumentsForPrintButton';

class ErrorDocumentsForPrint extends Component {
    render() {
        return (
        <div className="body">
        <br />    
        
        <VPLoggedPage />
        <form>     
              <table cellSpacing="0" cellPadding="0" width="100%" align="center" border="0">
                    <tbody>
                       <ErrorDocumentsForPrintHeader />
                        <tr>
                            <td width="1" bgcolor="#0066ce"><img height="1" src="images/dsPrint/spacer.gif" width="1" /></td>
                            <td width="100%" colSpan="6" >
                                
                                <table cellSpacing="1" cellPadding="1" width="100%" align="center" border="0">
                                    <tbody>
                                        <ErrorDocumentsForPrintHeadings />
                                        <ErrorDocumentsForPrintData />
                                        <tr>
                                            <td width="100%" colSpan="8">&nbsp;</td>
                                        </tr>
                                        <ErrorDocumentsForPrintButton />
                                        <tr>
                                            <td width="100%" colSpan="8">&nbsp;</td>
                                        </tr>
                                        <tr className="body">
                                            <td width="100%" colSpan="8" height="21" align="center" className="HeadBold">recordsNotFound!...</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                            <td width="1" bgcolor="#0066ce"><img height="1" src="images/dsPrint/spacer.gif" width="1" /></td>
                        </tr>
                        <tr>
                            <td width="1" bgcolor="#0066ce"><img height="1" src="images/dsPrint/spacer.gif" width="1" /></td>
                            <td bgcolor="#0066ce" colSpan="6"><img height="1" src="images/dsPrint/spacer.gif" width="1" /></td>
                            <td width="1" bgcolor="#0066ce"><img height="1" src="images/dsPrint/spacer.gif" width="1" /></td>
                        </tr>
                    </tbody>
                </table>
            </form>
            </div>
        );
    }
}

export default ErrorDocumentsForPrint;
