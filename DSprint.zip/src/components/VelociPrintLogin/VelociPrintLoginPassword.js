import React, { Component } from 'react';

class VelociPrintLoginPassword extends Component {
    render() {
        return (
            <tr className="body">
                <td width="20%" colSpan="1" height="24" align="left">&nbsp;</td>
                <td width="30%" colSpan="1" height="24" align="left">Password</td>
                <td width="50%" colSpan="1" height="24" align="left">
                    <input type="Password" value="" size="15" style={{ border: "" }} />
                </td>
            </tr>
        );
    }
}

export default VelociPrintLoginPassword;
