import React, { Component } from 'react';

class PrintAlert extends Component {
    render() {
        return (
            <div className="body">
                <script language="JavaScript">
                    {alert("Printing in Progress!!")};
            </script>
            </div>
        );
    }
}

export default PrintAlert;
