import React, { Component } from 'react';
import BatchEntryBottomButtons from './BatchEntryBottom/BatchEntryBottomButtons';

class BatchEntryBottom extends Component {
    render() {
        return (
            <div className="BatchEntryBottom">
                <form>
                    <br />
                    <br />
                    <table cellSpacing="0" cellPadding="0" width="100%" align="center" border="0">
                        <tbody>
                            <BatchEntryBottomButtons />
                        </tbody>
                    </table>
                </form>

            </div>
        );
    }
}

export default BatchEntryBottom;
