import React, { Component } from 'react';
import {Link} from 'react-router-dom';

class PrinterButton extends Component {
    render() {
        return (
            <tr className="body">
                <td width="100%" colSpan="3" height="21" align="center">
                <Link to="/Printing"><input type="button" name="Print" value="Print" className="btn btn-primary" /></Link>&nbsp;
                <Link to="/VPLoggedPage"><input type="button" name="Cancel" value="Cancel" className="btn btn-primary" /></Link>
                </td>
            </tr>
        );
    }
}

export default PrinterButton;
