import React, { Component } from 'react';

class SeachBatch extends Component {
    render() {
        return (
            <tr className="body">
                <td width="40%" colSpan="1" height="21" align="left">&nbsp;&nbsp; Select Batch</td>
                <td width="40%" colSpan="1" height="21" align="left">&nbsp;
                <select className="inps">
                        <option value="" disabled hidden>Select</option>
                        <option value="ALL">ALL</option>
                        <option value="NB">NB</option>
                </select>
                </td>
                <td width="40%" colSpan="1" height="21" align="left"></td>
            </tr>


        );
    }
}

export default SeachBatch;
