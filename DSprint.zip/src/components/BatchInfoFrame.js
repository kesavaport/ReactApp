import React, { Component } from 'react';
class BatchInfoFrame extends Component {
    render() {
        return (
            <div className="BatchInfoFrame">
                <frameset rows="*,70" cols="*" framespacing="0" border="0">
                    {/* <frame src="<%=contextPath%>/jsp/dsprint/ListBatch.do" name="FRAME_PRINT_TOP" frameborder="0" scrolling="auto"> */}
                    <frame src="BatchInfoButton.html" name="FRAME_PRINT_BOTTOM" frameborder="0" scrolling="no" />
                </frameset>

            </div>
        );
    }
}

export default BatchInfoFrame;
