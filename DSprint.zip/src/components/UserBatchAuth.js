import React, { Component } from 'react';
import UserBatchAuthHeader from './UserBatchAuth/UserBatchAuthHeader';
import UserBatchAuthBatchName from './UserBatchAuth/UserBatchAuthBatchName';
import UserBatchAuthHeadings from './UserBatchAuth/UserBatchAuthHeadings';
import UserBatchAuthSelectionData from './UserBatchAuth/UserBatchAuthSelectionData';
import UserBatchAuthAddButton from './UserBatchAuth/UserBatchAuthAddButton';
import UserBatchAuthButtons from './UserBatchAuth/UserBatchAuthButtons';
class UserBatchAuth extends Component {
    render() {
        return (
           
            <form className="container2">
            <br />
            <br />
            <table cellSpacing="0" cellPadding="0" width="100%" align="center" border="0">
                <tbody>
                    <UserBatchAuthHeader />
                    <tr>
                        <td width="1" bgcolor="#0066ce">
                            <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                        </td>
                        <td width="100%" colSpan="4">
                            <table cellSpacing="0" cellPadding="0" width="100%" align="center" border="0">
                                <tbody>
                                    <UserBatchAuthBatchName />
                                    <tr className="body">
                                        <td width="100%" colSpan="4" height="23">&nbsp;</td>
                                    </tr>
                                </tbody>
                            </table>
                            <table cellSpacing="0" cellPadding="0" width="100%" align="center" border="0">
                                <tbody>
                                    <UserBatchAuthHeadings />                                   
                                    <UserBatchAuthSelectionData />                          
                                    <tr className="body">
                                        <td width="30%" colSpan="1" height="21" align="left" id="lable2"></td>
                                        <td width="30%" colSpan="1" height="21" align="left" id="lable3"></td>
                                        <td width="20%" colSpan="1" height="21" align="left" id="lable4"></td>
                                        <td width="20%" colSpan="1" height="21" align="left" id="lable5"></td>
                                    </tr>
                                    <UserBatchAuthAddButton />
                                    <tr className="body">
                                        <td width="100%" colSpan="4" height="23">&nbsp;</td>
                                    </tr>
                                    <UserBatchAuthButtons />
                                    <tr className="body">
                                        <td width="100%" colSpan="4" height="23">&nbsp;</td>
                                    </tr>
                                    <tr className="body">
                                        <td width="100%" bgcolor="#0066ce" colSpan="4">
                                            <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                                        </td>
                                    </tr>
                                </tbody>
                            </table> 
                            
                        </td>  
                        <td width="1" bgcolor="#0066ce">
                        <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                    </td>  
                    </tr>
                </tbody>
            </table>
            </form>
       
    
        );
    }
}

export default UserBatchAuth;
