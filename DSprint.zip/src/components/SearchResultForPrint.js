import React, { Component } from 'react';

class SearchResultForPrint extends Component {
    render() {
        return (
            <body className="body">
            <form>
            <br />
            <br />
            <input type="hidden" name="printerName" value="" />
               <table cellSpacing="0" cellPadding="0" width="100%" align="center" border="0">
                <tbody>
                 <tr>
                    <td width="1" className="body" width="1" height="23" bgcolor="#0066ce"></td>
                    <td width="102%" colSpan="3" align="left" className="HeadBold" bgcolor="#0066ce">&nbsp; Attribute Entry</td>
                    <td width="1" width="1" height="23" bgcolor="#0066ce"></td>
                 </tr>
                  <tr>
                    <td width="1" bgColor="#0066ce"><img height="1" src="images/dsPrint/spacer.gif" width="1" /></td>
                        <td width="100%" colSpan="3" >
                      <table cellSpacing="1" cellPadding="1" width="100%" align="center" border="0">
                       <tbody>
                          
                            <tr className="HeadTable">
                                <td width="10%" colSpan="1" height="21" align="center">
                                        <input type="checkbox" name="chkBox" />
                                        <input type="checkbox" name="chkBox" disabled="disabled" />
                                </td>						
                                <td width="10%" colSpan="1" height="21" align="left">docSetID</td>
                                <td width="15%" colSpan="1" height="21" align="left">batchName</td>
                                <td width="15%" colSpan="1" height="21" align="left">batchDate</td>
                                <td width="10%" colSpan="1" height="21" align="left">noOfDoc</td>
                                <td width="10%" colSpan="1" height="21" align="left">noOfCopies</td>
                                <td width="10%" colSpan="1" height="21" align="left">batchAttributeList</td>
                                <td width="10%" colSpan="1" height="21" align="left">batchAttributeList</td>
                                    
                            </tr>
                                <tr>
                                    <td width="10%" colSpan="1" height="21" align="center"><input type="checkbox" name="docSetPrintChk" value="" /></td>
                                    <td width="10%" colSpan="1" height="21" align="left"></td>
                                    <td width="15%" colSpan="1" height="21" align="left"></td>
                                    <td width="15%" colSpan="1" height="21" align="left"></td>
                                    <td width="10%" colSpan="1" height="21" align="left"></td>
                                    <td width="10%" colSpan="1" height="21" align="left"></td>						
                                    <td width="10%" colSpan="1" height="21" align="left"></td>		
                                </tr>					
                                <tr>
                                      <td>&nbsp;</td>
                                  </tr>
                                <tr>
                                      <td>&nbsp;</td>
                                  </tr>				  						
                                <tr>
                                    <td width="100%" colSpan="6" align="center" >
                                        <input type="button" name="Listdoc" value="View" className="btn btn-primary" />&nbsp;
                                        <input type="button" name="Print" value="Print" className="btn btn-primary" />
                                    </td>
                                </tr>
                                <tr>
                                    <td width="100%" colSpan="6">&nbsp;</td>
                                </tr>
                                <tr className="body">
                                    <td width="100%" colSpan="6" height="21" align="center" className="HeadBold"></td>
                                </tr>	
                            <tr>
                                <td width="100%" colSpan="6">&nbsp;</td>
                            </tr>
                            <tr className="HeadTable">
                                <td width="8%" colSpan="1" height="21" align="center">						
                                        <input type="checkbox" name="chkBox" className="btn btn-primary" />					
                                        <input type="checkbox" name="chkBox" disabled="disabled" className="btn btn-primary" />
                                </td>        
                                <td width="9%" colSpan="1" height="21" align="left">docID</td>
                                <td width="9%" colSpan="1" height="21" align="left">docSetID</td>
                                <td width="15%" colSpan="1" height="21" align="left">batchName</td>
                                <td width="15%" colSpan="1" height="21" align="left">batchDate</td>
                                <td width="15%" colSpan="1" height="21" align="left">attribute</td>			
                                <td width="15%" colSpan="1" height="21" align="left">attribute</td>
                                <td width="15%" colSpan="1" height="21" align="left">letterType</td>
                            </tr>				
                                <tr>
                                    <td width="8%" colSpan="1" height="21" align="center"><input type="checkbox" name="docSetPrintChk" value="" /></td>
                                    <td width="9%" colSpan="1" height="21" align="left"></td>
                                    <td width="9%" colSpan="1" height="21" align="left"></td>
                                    <td width="15%" colSpan="1" height="21" align="left"></td>
                                    <td width="15%" colSpan="1" height="21" align="left"></td>
                                    <td width="15%" colSpan="1" height="21" align="left"></td>				
                                    <td width="15%" colSpan="1" height="21" align="left"></td>
                                    <td width="15%" colSpan="1" height="21" align="left"></td>
                                </tr>
                                <tr>
                                      <td>&nbsp;</td>
                                  </tr>
                                <tr>
                                    <td width="100%" colSpan="8" align="center">
                                        <input type="button" name="print" value="Print" className="btn btn-primary"/>		
                                    </td>
                                </tr>
                                <tr>
                                    <td width="100%" colSpan="8">&nbsp;</td>
                                </tr>
                                <tr className="body">
                                    <td width="100%" colSpan="8" height="21" align="center" className="HeadBold"></td>
                                </tr>
                                <tr>
                                    <td width="100%" colSpan="8">&nbsp;</td>
                                </tr>
                        </tbody>
                       </table>
                    </td>
                      <td width="1" bgColor="#0066ce"><img height="1" src="images/dsPrint/spacer.gif" width="1" /></td>
                 </tr>
                 <tr>
                      <td width="1" bgColor="#0066ce"><img height="1" src="images/dsPrint/spacer.gif" width="1" /></td>
                      <td bgColor="#0066ce" colSpan="6"><img height="1" src="images/dsPrint/spacer.gif" width="1" /></td>
                      <td width="1" bgColor="#0066ce"><img height="1" src="images/dsPrint/spacer.gif" width="1" /></td>
                 </tr>
                 </tbody>
                </table>
            </form>
            </body>
        );
    }
}

export default SearchResultForPrint;
