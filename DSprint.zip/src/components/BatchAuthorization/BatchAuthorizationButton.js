import React, { Component } from 'react';
import { Link } from 'react-router-dom';

class BatchAuthorizationButton extends Component {
    render() {
        return (
            <tr className="body">
                <td width="100%" colSpan="4" height="21" align="center">
                    <Link to="/UserListForBatchAuth"><input type="button" name="Cancel" value="Cancel" className="btn btn-primary" /></Link>
                </td>
            </tr>

        );
    }
}

export default BatchAuthorizationButton;
