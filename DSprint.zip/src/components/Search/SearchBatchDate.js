import React, { Component } from 'react';
import CalImg from '../../images/dsPrint/cal.gif';

class SearchBatchDate extends Component {
    render() {
        return (
            <tr className="body">
                <td height="21" width="20%">&nbsp;&nbsp; BATCHDATE </td>
                <td height="21" width="20%">
                    <select name="docSetVO" property="operator">
                        <option value="=">=</option>
                    </select>
                </td>
                <td height="21" width="40%">
                    <input type="text" name="columnValue" size="15" id="f_date_c" readOnly="readOnly" />
                    &nbsp;<img align="middle" id="f_trigger_c" title="" src={CalImg} width="17" height="20" border="0" />
                </td>
            </tr>


        );
    }
}

export default SearchBatchDate;
