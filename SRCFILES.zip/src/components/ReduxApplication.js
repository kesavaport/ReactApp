import React, { Component } from 'react';
import ParentComponent from "./FurtherRequirements/parentComponent"
import { Provider } from 'react-redux';  
import { store } from '../reducers/store';

export class ReduxApplication extends Component {

    render() {

        return (
            <Provider store={store}>
                <ParentComponent />
            </Provider>
        )
    }
}
//export default ReduxApplication;