import React, { Component } from 'react';

class DeleteDocsMsg extends Component {
    render() {
        return (
            <tr className="body">
                <td width="100%" colSpan="7" height="21" align="center" className="HeadBold">NoRecFound</td>
            </tr>

        );
    }
}

export default DeleteDocsMsg;
