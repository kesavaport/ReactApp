import React, { Component } from 'react';
import DeleteDocsHeader from './DeleteDocs/DeleteDocsHeader';
import DeleteDocsHeadings from './DeleteDocs/DeleteDocsHeadings';
import DeleteDocsData from './DeleteDocs/DeleteDocsData';
import DeleteDocsMsg from './DeleteDocs/DeleteDocsMsg';
import DeleteDocsButtons from './DeleteDocs/DeleteDocsButtons';

class DeleteDocs extends Component {
    render() {
        return (
            <div className="body">
            <br />
            <br />
            <form>
                <table cellSpacing="0" cellPadding="0" width="100%" align="center" border="0">
                    <tbody>
                        <DeleteDocsHeader />
                        <tr>
                            <td width="1" bgcolor="#0066ce">
                                <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                            </td>
                            <td width="100%" colSpan="5">
                                <table cellSpacing="1" cellPadding="1" width="100%" align="center" border="0">
                                    <tbody>
                                       <DeleteDocsHeadings />                                    
                                        <DeleteDocsData />
                                        <tr>
                                            <td width="100%" colSpan="7">&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td width="100%" colSpan="7">&nbsp;</td>
                                        </tr>
                                       <DeleteDocsMsg />
                                        <tr>
                                            <td width="100%" colSpan="7">&nbsp;</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                            <td width="1" bgcolor="#0066ce">
                                <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                            </td>
                        </tr>
                        <tr>
                            <td width="1" bgcolor="#0066ce">
                                <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                            </td>
                            <td bgcolor="#0066ce" colSpan="5">
                                <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                            </td>
                            <td width="1" bgcolor="#0066ce">
                                <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                            </td>
                        </tr>
                    </tbody>
                </table>
            </form>
            <DeleteDocsButtons />
        </div>
        
        );
    }
}

export default DeleteDocs;
