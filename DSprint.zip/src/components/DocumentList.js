import React, { Component } from 'react';
import DocumentListHeader from './DocumentList/DocumentListHeader';
import DocumentListHeadings from './DocumentList/DocumentListHeadings';
import DocumentListSelection from './DocumentList/DocumentListSelection';
import DocumentListMsg from './DocumentList/DocumentListMsg';
import DocumentListButtons from './DocumentList/DocumentListButtons';
import VPLoggedPage from './VPLoggedPage';

class DocumentList extends Component {
    render() {
        return (
            <div className="body">           
             <VPLoggedPage />
               <br />
                <form>
                    <table cellSpacing="0" cellPadding="0" width="100%" align="center" border="0">
                        <tbody>
                            <DocumentListHeader />
                            <tr>
                                <td width="1" bgcolor="#0066ce">
                                    <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                                </td>
                                <td width="100%" colSpan="9">
                                    <table cellSpacing="1" cellPadding="1" width="100%" align="center" border="0">
                                        <tbody>
                                            <DocumentListHeadings />
                                            <DocumentListSelection />
                                            <tr>
                                                <td>&nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td width="100% " colSpan="9 " align="center ">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>&nbsp;</td>
                                            </tr>

                                            <DocumentListButtons />

                                            <tr>
                                                <td width="100% " colSpan="9 ">&nbsp;</td>
                                            </tr>

                                            <DocumentListMsg />
                                            <tr>
                                                <td width="100% " colSpan="9 ">&nbsp;</td>
                                            </tr>

                                        </tbody>
                                    </table>
                                </td>
                                <td width="1 " bgcolor="#0066ce"><img height="1" src="images/dsPrint/spacer.gif " width="1" /></td>
                            </tr>
                            <tr>
                                <td width="1" bgcolor="#0066ce"><img height="1" src="images/dsPrint/spacer.gif " width="1" /></td>
                                <td bgcolor="#0066ce" colSpan="8"><img height="1" src="images/dsPrint/spacer.gif " width="1" /></td>
                                <td width="1" bgcolor="#0066ce"><img height="1" src="images/dsPrint/spacer.gif " width="1" /></td>
                            </tr>
                        </tbody>
                    </table>
                </form>
            </div>
        );
    }
}
export default DocumentList;