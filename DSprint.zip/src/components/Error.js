import React, { Component } from 'react';
import ErrorHeader from './Error/ErrorHeader';
import ErrorImage from './Error/ErrorImage';
//import Spacer from '../images/dsPrint/spacer.gif';
class Error extends Component {
  render() {
    return (
  <div className="Error">
      
  <br />
  <br />
  <table cellSpacing="0" cellPadding="0" width="100%" align="center" border="0">
      <tbody>
         <ErrorHeader />
          <tr>
              <td width="1" bgColor="#0066ce">
                  <img height="1" src="images/dsPrint/spacer.gif" width="1" />
              </td>
              <td width="100%" colSpan="3">
                  <table cellSpacing="0" cellPadding="0" width="100%" align="center" border="0">
                      <tbody>
                          <tr className="body">
                              <td width="100%" colSpan="3" height="21">&nbsp;</td>
                          </tr>
                          <tr className="body">
                              <td width="100%" colSpan="3" height="23">&nbsp;</td>
                          </tr>
                          <ErrorImage />
                          <tr className="body">
                              <td width="100%" bgColor="#0066ce" colSpan="3">
                                  <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                              </td>
                          </tr>
                      </tbody>
                  </table>
                  </td>
                  <td width="1" bgColor="#0066ce">
                      <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                  </td>
          </tr>
      </tbody>
  </table>
  </div>
    );
  }
}

export default Error;
