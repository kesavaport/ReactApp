import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import DocumentList from '../DocumentList';
class DocSetListButtons extends Component {
    render() {
        return (
            <tr>
                <td width="100%" colSpan="7" align="center">
                    <Link to="/DocumentList"><input type="button" name="Listdoc" value="List Documents" className="btn btn-primary" /></Link>&nbsp;
                    <Link to="/Printer"><input type="button" name="Print" value="Print" className="btn btn-primary" /></Link>
                </td>
            </tr>
        );
    }
}

export default DocSetListButtons;
