import React, { Component } from 'react';

class AdminRolesHeader extends Component {
  render() {
    return (

    <table cellSpacing="0" cellPadding="0" align="center" width="100%" border="0">
        <tr bgcolor="#0066ce" className="HeadBold" >
            <td width="1" className="body" width="1" height="23"></td>
            <td width="102%" colspan="3" align="left">&nbsp;Admin Roles</td>
            <td width="1" width="1" height="23"></td>
        </tr>
    </table>
    );
  }
}

export default AdminRolesHeader;