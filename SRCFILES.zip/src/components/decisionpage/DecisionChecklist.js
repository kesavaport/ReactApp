import React from 'react';


class DCLComponent extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            checkboxenable: false
        }

        // this.handlerForSubmit=this.handlerForSubmit.bind(this);
        this.handlerChecked = this.handlerChecked.bind(this);
    }
    handlerChecked(flag) {
        // let temp=(e.target.checked);
        this.setState(() => {
            return {
                checkboxenable: flag,
                value: 1
            }
        });
        this.child.hello(flag);
    }


    render() {
        return (
            <div className="mdl-layout" id="dclHold">
                <div className="mdl-layout__content">
                    <div className="mdl-grid">
                        <div className="mdl-cell mdl-cell--12-col">
                            <div className="card">
                                <div className="card-content" style={{ color: "#000" }}>
                                    <div className="card-title">Decision Checklist</div>
                                    <CheckboxComponent handlerChecked={this.handlerChecked} />
                                    <MakeDecisionComponent onRef={ref => (this.child = ref)} />
                                </div>

                            </div>>

                </div>
                    </div>
                </div>
            </div>
        )
    }
}
export default DCLComponent;

class CheckboxComponent extends React.Component {
    constructor(props) {
        super(props);

        this.handlerChecked = this.handlerChecked.bind(this);
    }
    handlerChecked(e) {
        let temp = (e.target.checked);
        this.props.handlerChecked(temp);
        console.log("checked" + temp);
    }
    render() {
        return (
            <div className="">
                {/*<div className="mdl-cell  mdl-color-text--black mdl-cell--1-col-phone">AddressCreated</div>
                <div className="mdl-cell mdl-cell--1-col mdl-color-text--black mdl-cell--1-col-phone">&nbsp;</div>
                <div className="mdl-cell mdl-cell--1-col mdl-cell--2-col-phone">
                    <Checkbox label="" onClick={this.handlerChecked}  />
                </div>
        */}
                <div className="row">
                    <div className="col s12 m12">AddressCreated <span style={{ marginLeft: "10px" }}><input type="checkbox" id="test5" onClick={this.handlerChecked} /><label htmlFor="test5">&nbsp;</label></span></div>
                </div>
            </div>
        )
    }
}

class MakeDecisionComponent extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            checked: [1., 2], unchecked: [], checkboxenable: false, value: 1
        }
        this.handlerForSubmit = this.handlerForSubmit.bind(this);
    }
    handlerForSubmit(event) {
        event.preventDefault();
        console.log("DropDown Selected value: " + document.getElementsByClassName("dropdownstyle")[0].innerText)
    }
    handlerGet() {
        var t = this;
        fetch("./js/data.json") // Call the fetch function passing the url of the API as a parameter
            .then((resp) => resp.json())
            .then(function (data) {
                // Your code for handling the data you get from the API

                t.setState(() => {
                    return {
                        checked: data.checked,
                        unchecked: data.unchecked
                    }
                });
            })
            .catch(function (e) {
                // This is where you run code if the server returns any errors
                console.log(e);
            });
    }

    componentWillMount() {
        this.handlerGet();
    }


    componentDidMount() {
        this.props.onRef(this);
   

    }
    componentWillUnmount() {
        this.props.onRef(undefined)
    }
    componentDidUpdate(prevProps, prevState) {
       
    }
    hello(flag) {
        //console.log(flag);
        this.setState(() => {
            return {
                checkboxenable: flag, value: 1
            }
        })
        //console.log(this.state.checkboxenable);
    }
    handleChange = (event, index, value) => this.setState({ value });

    render() {
        return (
            <div className="">
                {/*
                <div className="mdl-cell mdl-cell--1-col mdl-cell--4-col-phone mdl-cell--2-col-tablet" style={{lineHeight:'60px'}}><strong>Decision</strong></div>
                <div className="mdl-cell mdl-cell--3-col mdl-cell--4-col-phone mdl-cell--3-col-tablet">
                    
            

            {(!this.state.checkboxenable) && 
                <DropDownMenu value={this.state.value} onChange={this.handleChange} className="dropdownstyle" >
                {
                 this.state.unchecked.map((value, index)=>{
                   return(
                       <MenuItem key={index} value={index+1} primaryText={value}> </MenuItem>
                 )
               })
                }
               </DropDownMenu>   
            }
            {(this.state.checkboxenable) && 
              <DropDownMenu value={this.state.value} onChange={this.handleChange} className="dropdownstyle" >
               {
                this.state.checked.map((value, index)=>{
                  return(
                      <MenuItem key={index} value={index+1} primaryText={value}> </MenuItem>
                )
              })
               }
              </DropDownMenu>
              }     

                
                </div>
                <div className="mdl-cell mdl-cell--3-col mdl-cell--4-col-phone mdl-cell--3-col-tablet">
                <form action="#" onSubmit={this.handlerForSubmit}>
                    <RaisedButton  className="btnStyle"  type="submit">
                     <span style={{color:'#fff',position:'relative',top:'5px'}}>
                        <i className= 'mdl-icon-toggle__label material-icons'>done</i>
                     </span>
                     Take Decision
                    </RaisedButton>
                </form>
                </div>
                
                
            */}

                {(true) &&
                    <div>
                        <a className='dropdown-button btn' href='#' data-activates='dropdown1' style={{ color: "#000" }}>Drop Me!</a>


                        <ul id='dropdown1' className='dropdown-content'>

                            {
                                this.state.unchecked.map((value, index) => {
                                    return (
                                        <li key={index} style={{ color: "#000" }}>{value}</li>
                                    )
                                })
                            }
                        </ul>
                    </div>

                }

                {(false) &&
                    <div>
                        <a className='dropdown-button btn' href='#' data-activates='dropdown2' style={{ color: "#000" }}>Drop Me!</a>


                        <ul id='dropdown2' className='dropdown-content'>

                            {
                                this.state.checked.map((value, index) => {
                                    return (
                                        <li key={index} style={{ color: "#000" }}>{value}</li>
                                    )
                                })
                            }
                        </ul>
                    </div>

                }

               

            </div>
        )
    }
}