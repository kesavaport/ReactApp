import React, { Component } from 'react';
import Printer from '../Printer';
import { BrowserRouter, Route, Switch, Link, NavLink } from 'react-router-dom';

class DocumentListButtons extends Component {
    render() {
        return (
            <tr>
            <td width="100%" colSpan="9" align="center">
            <Link to="/Printer"><input type="button" name="Print" value="Print" className="btn btn-primary" /></Link>&nbsp;
            <Link to="/DocSetList"><input type="button" name="Back" value="Back" className="btn btn-primary" /></Link>
            </td>
            </tr>
        );
    }
}

export default DocumentListButtons;
