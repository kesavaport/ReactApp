import React, { Component } from 'react';
import AttributeListHeader from './BatchAttributeList/AttributeListHeader';
import AttributeHeadings from './BatchAttributeList/AttributeHeadings';
import BatchAttributeSelect from './BatchAttributeList/BatchAttributeSelect';
import BatchButtons from '../components/BatchAttributeButton/BatchButtons';
class BatchAttributeList extends Component {
    render() {
        return (
            <div className="BatchAttributeList">
                <br />
                <br />
                <form>
                    <table cellSpacing="0" cellPadding="0" width="100%" align="center" border="0">
                        <tbody>
                            <AttributeListHeader />
                            <tr>
                                <td width="1" bgcolor="#0066ce"><img height="1" src="images/dsPrint/spacer.gif" width="1" /></td>
                                <td width="100%" colSpan="3" >
                                    <table cellSpacing="1" cellPadding="1" width="100%" align="center" border="0">
                                        <tbody>
                                            <AttributeHeadings />
                                            <BatchAttributeSelect />
                                            <tr>
                                                <td width="100%" colSpan="3">&nbsp;</td>
                                            </tr>                                           
                                            <tr>
                                                <td width="100%" colSpan="3">&nbsp;</td>
                                            </tr>
                                            <tr className="body">
                                                <td width="100%" colSpan="3" height="21" align="center" className="HeadBold"></td>
                                            </tr>
                                            <tr>
                                                <td width="100%" colSpan="3">&nbsp;</td>
                                            </tr>

                                        </tbody>
                                    </table>
                                </td>
                                <td width="1" bgcolor="#0066ce"><img height="1" src="images/dsPrint/spacer.gif" width="1" /></td>
                            </tr>
                            <tr>
                                <td width="1" bgcolor="#0066ce"><img height="1" src="images/dsPrint/spacer.gif" width="1" /></td>
                                <td bgcolor="#0066ce" colSpan="3"><img height="1" src="images/dsPrint/spacer.gif" width="1" /></td>
                                <td width="1" bgcolor="#0066ce"><img height="1" src="images/dsPrint/spacer.gif" width="1" /></td>
                            </tr>
                        </tbody>
                    </table>
                    <BatchButtons />
                </form>
            </div>
        );
    }
}
export default BatchAttributeList;