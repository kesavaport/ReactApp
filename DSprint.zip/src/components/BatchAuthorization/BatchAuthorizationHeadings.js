import React, { Component } from 'react';

class BatchAuthorizationHeadings extends Component {
    render() {
        return (
            <tr className="HeadTable BatchAuthorizationHeadings" >
                <td width="15%" colSpan="1" height="21" align="center">Serial No.</td>
                <td width="35%" colSpan="1" height="21" align="left">Batch Name</td>
                <td width="30%" colSpan="1" height="21" align="left">Status</td>
                <td width="20%" colSpan="1" height="21" align="center">Remove</td>
            </tr>
        );
    }
}

export default BatchAuthorizationHeadings;
