import React, { Component } from 'react';

class ErrorDocumentsForPrintHeader extends Component {
    render() {
        return (
            <tr>
                <td width="1" className="body" width="1" height="23" bgcolor="#0066ce"></td>
                <td width="102%" colSpan="8" align="left" className="HeadBold" bgcolor="#0066ce">&nbsp; Error Documents for Print</td>
                <td width="1" width="1" height="23" bgcolor="#0066ce"></td>
            </tr>

        );
    }
}

export default ErrorDocumentsForPrintHeader;
