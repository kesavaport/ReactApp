import React, { Component } from 'react';
import BatchAuthorizationHeader from './BatchAuthorization/BatchAuthorizationHeader';
import BatchAuthorizationHeadings from './BatchAuthorization/BatchAuthorizationHeadings';
import BatchAuthorizationStatus from './BatchAuthorization/BatchAuthorizationStatus';
import BatchAuthorizationButton from './BatchAuthorization/BatchAuthorizationButton';
import BatchAuthorizationStatusMsg from './BatchAuthorization/BatchAuthorizationStatusMsg';
class BatchListForAuthorization extends Component {
    render() {
        return (
            <div className="BatchListForAuthorization">
                <br/>    
                <table cellSpacing="0" cellPadding="0" width="100%" align="center" border="0">
                    <tbody>
                        <BatchAuthorizationHeader />
                        <tr>
                            <td width="1" bgcolor="#0066ce">
                                <img height="1" src="/images/dsPrint/spacer.gif" width="1" />
                            </td>
                            <td width="100%" colSpan="4">
                                <table cellSpacing="1" cellPadding="1" width="100%" align="center" border="0">
                                    <tbody>
                                        <BatchAuthorizationHeadings />
                                        <BatchAuthorizationStatus />
                                        <tr className="body">
                                            <td width="100%" colSpan="4" height="21">&nbsp;</td>
                                        </tr>
                                        <BatchAuthorizationStatusMsg />
                                        <tr className="body">
                                            <td width="100%" colSpan="4" height="21">&nbsp;</td>
                                        </tr>
                                        <BatchAuthorizationButton />
                                        <tr>
                                            <td width="100%" colSpan="4">&nbsp;</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                            <td width="1" bgcolor="#0066ce">
                                <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                            </td>
                        </tr>
                        <tr>
                            <td width="1" bgcolor="#0066ce">
                                <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                            </td>
                            <td bgcolor="#0066ce" colSpan="4">
                                <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                            </td>
                            <td width="1" bgcolor="#0066ce">
                                <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                            </td>
                        </tr>
                    </tbody>
                </table>

            </div>
        );
    }
}

export default BatchListForAuthorization;
