import React, { Component } from 'react';

class AdminRolesUsers extends Component {
  render() {
    return (
        <tr>
          <td height="35" width="100">
            <input type="button" name="user" value="Users" className="btn btn-primary" />
          </td>
        </tr>
    );
  }
}

export default AdminRolesUsers;