import React, { Component } from 'react';

class BatchInfoDescription extends Component {
    render() {
        return (
            <tr className="body">
                <td width="20%" colSpan="1" height="21" align="left">&nbsp;Batch Description</td>

                <td width="40%" colSpan="1" height="21" align="left">&nbsp;<textarea name="batchDescription" rows="2" cols="25"></textarea></td>
                <td width="40%" colSpan="1" height="21" align="left"></td>
            </tr>

        );
    }
}

export default BatchInfoDescription;
