import React, { Component } from 'react';

class Login extends Component {
  render() {
    return (
      <tr className="body">
        <td width="100%" colSpan="3" height="21" align="center">

          <input type="button" name="Login" value="Login" className="btn btn-primary" />	&nbsp;
          <input type="button" name="Cancel" value="Cancel" className="btn btn-primary" />
        </td>
      </tr>
    );
  }
}

export default Login;
