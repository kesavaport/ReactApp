// actions.js
// export const activateGeod = geod => ({  
//     type: 'ACTIVATE_GEOD',
//     geod,
//   });
  
//   export const closeGeod = () => ({  
//     type: 'CLOSE_GEOD',
//   });

  export const updateCaseReq =(deletedIndex)=> ({
      type:'Update_CaseReq',
      deletedIndex
  })

  export const updateOutReq =(deletedIndex)=> ({
    type:'Update_OutReq',
    deletedIndex
})
