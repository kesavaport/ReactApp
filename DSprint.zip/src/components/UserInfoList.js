import React, { Component } from 'react';
import UserInfoBottom from '../components/UserInfoBottom';
import UserInfoListHeader from './UserInfoList/UserInfoListHeader';
import UserInfoListHeadings from './UserInfoList/UserInfoListHeadings';
import UserInfoListData from './UserInfoList/UserInfoListData';
import UserInfoListMsg from './UserInfoList/UserInfoListMsg';
class UserInfoList extends Component {
    render() {
        return (
            <div>
            <br />
            <br />
            <table cellSpacing="0" cellPadding="0" width="100%" align="center" border="0">
                <tbody>
                    <UserInfoListHeader />
                    <tr>
                        <td width="1" bgcolor="#0066ce">
                            <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                        </td>
                        <td width="102%" colSpan="2">
                            <table cellSpacing="1" cellPadding="1" width="100%" align="center" border="0">
                                <tbody>
                                    <UserInfoListHeadings />
                                    <UserInfoListData />
                                    <tr>
                                        <td width="100%" colSpan="2">&nbsp;</td>
                                    </tr>
                                    <UserInfoListMsg />
                                    <tr>
                                        <td width="100%" colSpan="2">&nbsp;</td>
                                    </tr>
                                </tbody>
                            </table>
                        </td>
                        <td width="1" bgcolor="#0066ce">
                            <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                        </td>
                    </tr>
                    <tr>
                        <td width="1" bgcolor="#0066ce">
                            <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                        </td>
                        <td bgcolor="#0066ce" colSpan="2">
                            <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                        </td>
                        <td width="1" bgcolor="#0066ce">
                            <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                        </td>
                    </tr>
                </tbody>
            </table>
            <br/>
            <br/>
            <UserInfoBottom />
        </div>
        );
    }
}

export default UserInfoList;
