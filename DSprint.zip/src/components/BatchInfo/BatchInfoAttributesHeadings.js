import React, { Component } from 'react';

class BatchInfoAttributesHeadings extends Component {
  render() {
    return (
      <tr className="HeadTable">
        <td width="20%" colSpan="1" height="21" align="left">Select</td>
        <td width="30%" colSpan="1" height="21" align="left">Attribute Name</td>
        <td width="40%" colSpan="1" height="21" align="left">Attribute Value</td>
      </tr>
    );
  }
}

export default BatchInfoAttributesHeadings;