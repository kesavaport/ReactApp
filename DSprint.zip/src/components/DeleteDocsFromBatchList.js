import React, { Component } from 'react';
import DeleteDocsFromBatchListDetails from './DeleteDocsFromBatchList/DeleteDocsFromBatchListDetails';
import DeleteDocsFromBatchListHeader from './DeleteDocsFromBatchList/DeleteDocsFromBatchListHeader';
import DeleteDocsFromBatchListHeadings from './DeleteDocsFromBatchList/DeleteDocsFromBatchListHeadings';
import DeleteDocsFromBatchListMsg from './DeleteDocsFromBatchList/DeleteDocsFromBatchListMsg';
import DeleteDocsFromBatchListButtons from './DeleteDocsFromBatchList/DeleteDocsFromBatchListButtons';

class DeleteDocsFromBatchList extends Component {
    render() {
        return (
            <div className="DeleteDocsFromBatchList">
                <form>
                <br />
                <br />
                    <table cellSpacing="0" cellPadding="0" width="100%" align="center" border="0">
                        <tbody>
                            <DeleteDocsFromBatchListHeader />
                            <tr>
                                <td width="1" bgcolor="#0066ce">
                                    <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                                </td>
                                <td width="100%" colSpan="4">
                                    <table cellSpacing="1" cellPadding="1" width="100%" align="center" border="0">
                                        <tbody>
                                            <DeleteDocsFromBatchListHeadings />
                                            
                                            <DeleteDocsFromBatchListDetails />
                                            
                                            <tr>
                                                <td width="100%" colSpan="4">&nbsp;</td>
                                            </tr>
                                            <DeleteDocsFromBatchListMsg />
                                            <tr>
                                                <td width="100%" colSpan="4">&nbsp;</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                                <td width="1" bgcolor="#0066ce">
                                    <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                                </td>
                            </tr>
                            <tr>
                                <td width="1" bgcolor="#0066ce">
                                    <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                                </td>
                                <td bgcolor="#0066ce" colSpan="4">
                                    <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                                </td>
                                <td width="1" bgcolor="#0066ce">
                                    <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </form>
                <DeleteDocsFromBatchListButtons />
            </div>
        );
    }
}

export default DeleteDocsFromBatchList;
