import React, { Component } from 'react';

class AdminRolesBatches extends Component {
  render() {
    return (
        <tr>
           <td height="35" width="100">
              <input type="button" name="batch" value="Batches" className="btn btn-primary" />
           </td>
        </tr>
    );
  }
}

export default AdminRolesBatches;