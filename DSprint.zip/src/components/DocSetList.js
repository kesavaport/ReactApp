import React, { Component } from 'react';
import DocSetListHeader from './DocSetList/DocSetListHeader';
import DocSetListHeadings from './DocSetList/DocSetListHeadings';
import DocsetListSelection from './DocSetList/DocsetListSelection';
import DocSetListButtons from './DocSetList/DocSetListButtons';
import DocSetListMsg from './DocSetList/DocSetListMsg';
import VPLoggedPage from './VPLoggedPage';

class DocSetList extends Component {
    render() {
        return (
            <div className="DocSetList">
                <VPLoggedPage />
                <br />
                <form>
                    <table cellSpacing="0" cellPadding="0" width="100%" align="center" border="0">

                        <tbody>
                            <DocSetListHeader />
                            <tr>
                                <td width="1" bgcolor="#0066ce">
                                    <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                                </td>
                                <td width="100%" colSpan="6">
                                    <table cellSpacing="1" cellPadding="1" width="100%" align="center" border="0">
                                        <tbody>
                                            <DocSetListHeadings />
                                            <DocsetListSelection />
                                            <tr>
                                                <td>&nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td width="100%" colSpan="7" align="center">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>&nbsp;</td>
                                            </tr>
                                            <DocSetListButtons />
                                            <tr>
                                                <td width="100%" colSpan="6">&nbsp;</td>
                                            </tr>
                                            <DocSetListMsg />
                                            <tr>
                                                <td width="100%" colSpan="6">&nbsp;</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                                <td width="1" bgcolor="#0066ce">
                                    <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                                </td>
                            </tr>
                            <tr>
                                <td width="1" bgcolor="#0066ce">
                                    <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                                </td>
                                <td bgcolor="#0066ce" colSpan="6">
                                    <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                                </td>
                                <td width="1" bgcolor="#0066ce">
                                    <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </form>

            </div>
        );
    }
}

export default DocSetList;
