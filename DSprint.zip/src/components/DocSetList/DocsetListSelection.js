import React, { Component } from 'react';

class DocsetListSelection extends Component {
    render() {
        return (
            
            <tr className="body">
            <td width="10%" colSpan="1" height="21" align="center">
                <input type="checkbox" name="docSetPrintChk" value="docSetid" />
            </td>
            <td width="10%" colSpan="1" height="21" align="left">10</td>
            <td width="20%" colSpan="1" height="21" align="left">AWPL</td>
            <td width="15%" colSpan="1" height="21" align="left">2017/12/20</td>
            <td width="10%" colSpan="1" height="21" align="left">4</td>
            <td width="15%" colSpan="1" height="21" align="left">1</td>
            <td width="20%" colSpan="1" height="21" align="left">To be Printed</td>
           </tr>
           
        
        );
    }
}

export default DocsetListSelection;
