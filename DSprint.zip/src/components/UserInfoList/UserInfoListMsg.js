import React, { Component } from 'react';

class UserInfoListMsg extends Component {
    render() {
        return (
            <tr>
                <td width="100%" colSpan="2" height="21" align="center" className="body">No Rec. Found</td>
            </tr>
        );
    }
}

export default UserInfoListMsg;
