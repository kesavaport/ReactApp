import React, { Component } from 'react';
class BatchListSelection extends Component {
    render() {
        return (

            <tr className="body BatchListSelection">
                <td width="10%" colSpan="1" height="21" align="center"><input type="radio" name="radioValue" value="" /></td>
                <td width="30%" colSpan="1" height="21" align="left">AWPL</td>
                <td width="40%" colSpan="1" height="21" align="left">Automated workflow Pvt. Ltd.</td>
                <td width="20%" colSpan="1" height="21" align="left">1</td>
            </tr>

        );
    }
}

export default BatchListSelection;
