import React, { Component } from 'react';

class ErrorsForRouterButton extends Component {
    render() {
        return (
            <tr>
                <td width="100%" colSpan="6" align="center">
                    <input type="button" className="btn btn-primary" name="RetryRequest" value="Replay" />
                </td>
            </tr>

        );
    }
}

export default ErrorsForRouterButton;
