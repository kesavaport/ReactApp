import React, { Component } from 'react';

class DeleteDocsHeadings extends Component {
    render() {
        return (
            <tr className="HeadTable">
                <td width="10%" colSpan="1" height="21" align="center">
                    <input type="checkbox" name="chkBox" disabled="disabled" />
                </td>
                <td width="20%" colSpan="1" height="21" align="left">Batch Name</td>
                <td width="15%" colSpan="1" height="21" align="left">Batch Date</td>
                <td width="17%" colSpan="1" height="21" align="left">Document Type</td>
                <td width="10%" colSpan="1" height="21" align="left">Print Status</td>
            </tr>

        );
    }
}

export default DeleteDocsHeadings;
