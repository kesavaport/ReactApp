import React, { Component } from 'react';
import {Link} from 'react-router-dom';
class BatchInfoButtons extends Component {
    render() {
        return (
        <table cellSpacing="0" cellPadding="0" width="100%" align="center" border="0" className="body">
        <tbody>
             <tr>
               <td width="100%" colSpan="3" align="center">
               <Link to="/Success"><input type="button" name="ok" value="Ok" className="btn btn-primary" height="2px" width="5px" /></Link>&nbsp;
               <Link to="/AdminRouting"><input type="button" name="Cancel" value="Cancel" className="btn btn-primary" /></Link>
               </td> 
             </tr>
         </tbody>
       </table>
        );
    }
}

export default BatchInfoButtons;
