import React, { Component } from 'react';
import { BrowserRouter, Route, Switch, Link, NavLink } from 'react-router-dom';
class UserInfoBottom extends Component {
    render() {
        return (
           
            <table cellSpacing="0" cellPadding="0" width="100%" align="center" border="0" className="body">
             <tbody>
                  <tr>
                    <td width="100%" colSpan="3" align="center">
                        <Link to="UserInfoEntry"><input type="button" name="Update" value="Update" className="btn btn-primary inps" /></Link>&nbsp;
                        <Link to="UserInfoEntry"><input type="button" name="Delete" value="Delete" className="btn btn-primary inps" /></Link>&nbsp;
                        <Link to="UserInfoEntry"><input type="button" name="Add" value="Add" className="btn btn-primary inps" /></Link>&nbsp;
                    </td> 
                  </tr>
              </tbody>
            </table>
           
        );
    }
}

export default UserInfoBottom;
