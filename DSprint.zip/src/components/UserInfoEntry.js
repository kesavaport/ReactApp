import React, { Component } from 'react';
import UserInfoEntryHeader from './UserInfoEntry/UserInfoEntryHeader';
import UserInfoEntryUsername from './UserInfoEntry/UserInfoEntryUsername';
import UserInfoEntryPassword from './UserInfoEntry/UserInfoEntryPassword';
import UserInfoEntryConfirmPassword from './UserInfoEntry/UserInfoEntryConfirmPassword';
import UserInfoEntryButton from './UserInfoEntry/UserInfoEntryButton';

class UserInfoEntry extends Component {
    render() {
        return (
            <div className="body">
                
                <form>
                    <br />
                    <br />
                    <table cellSpacing="0" cellPadding="0" width="40%" align="center" border="0">
                        <tbody>
                            <UserInfoEntryHeader />
                            <tr>
                                <td width="1" bgcolor="#0066ce"><img height="1" src="images/dsPrint/spacer.gif" width="1" /></td>
                                <td width="100%" colSpan="3" >
                                    <table cellSpacing="0" cellPadding="0" width="100%" align="center" border="0">
                                        <tbody>
                                            <tr className="body">
                                                <td width="100%" colSpan="3" height="21">&nbsp;</td>
                                            </tr>
                                             
                                            <UserInfoEntryUsername />
 
                                            <UserInfoEntryPassword />

                                            <UserInfoEntryConfirmPassword />

                                            <tr className="body">
                                                <td width="100%" colSpan="3" height="21">&nbsp;</td>
                                            </tr>

                                            <UserInfoEntryButton />

                                            <tr className="body">
                                                <td width="100%" colSpan="3" height="23">&nbsp;</td>
                                            </tr>

                                            <tr className="body">
                                                <td width="100%" bgcolor="#0066ce" colSpan="3"><img height="1" src="images/dsPrint/spacer.gif" width="1" /></td>
                                            </tr>

                                        </tbody>
                                    </table>
                                </td>
                                <td width="1" bgcolor="#0066ce"><img height="1" src="images/dsPrint/spacer.gif" width="1" /></td>
                            </tr>
                        </tbody>
                    </table>
                </form>
               
            </div>
        );
    }
}

export default UserInfoEntry;
