import React, { Component } from 'react';
import {  NavLink } from 'react-router-dom';

class DeleteDocsFromDocSetListData extends Component {
    render() {
        return (
            <tr className="body">
                <td width="10%" colSpan="1" height="21" align="center">
                    <input type="checkbox" name="docSetPrintChk" value="docSetId" />
                </td>
                <td width="20%" colSpan="1" height="21" align="left"><NavLink to="DeleteDocs">AWPL</NavLink></td>
                <td width="15%" colSpan="1" height="21" align="left">1</td>
                <td width="20%" colSpan="1" height="21" align="left">2018-08-09</td>
                <td width="20%" colSpan="1" height="21" align="left"></td>
                <td width="15%" colSpan="1" height="21" align="left">Printed</td>
            </tr>
        );
    }
}

export default DeleteDocsFromDocSetListData;
