import React, { Component } from 'react';
import { Link } from 'react-router-dom';

class VelociPrintLoginButton extends Component {
    render() {
        return (
            <tr className="body">
            <td width="100%" colSpan="3" height="21" align="center">
               <Link to="/LoginPage"> <input type="button" name="Login" value="Login" className="btn btn-primary" /></Link>
            </td>
        </tr> 
        );
    }
}

export default VelociPrintLoginButton;
