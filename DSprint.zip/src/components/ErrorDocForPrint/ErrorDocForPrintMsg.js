import React, { Component } from 'react';

class ErrorDocForPrintMsg extends Component {
    render() {
        return (
            <tr className="body">
                <td width="100%" colSpan="7" height="21" align="center" className="HeadBold">recordsNotFound!...</td>
            </tr>
        );
    }
}

export default ErrorDocForPrintMsg;
