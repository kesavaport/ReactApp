import React, { Component } from 'react';
class ErrorDocForPrint extends Component {
    render() {
        return (
            <div className="ErrorDocForPrint">
            <form>
            <table cellSpacing="0" cellPadding="0" width="100%" align="center" border="0">
            <tbody>
                <tr>
                    <td width="1" class="body" width="1" height="23" bgcolor="#0066ce"></td>
                    <td width="102%" colspan="8" align="left" class="HeadBold" bgcolor="#0066ce">&nbsp; Error Document for Print</td>
                  <td width="1" width="1" height="23" bgcolor="#0066ce"></td>
              </tr>
            <tr>
              <Td width="1" bgColor="#0066ce"><IMG height="1" src="images/dsPrint/spacer.gif" width="1" /></Td>
              <td width="100%" colspan="6" >
                    <table cellSpacing="1" cellPadding="1" width="100%" align="center" border="0">
                    <tbody>
                        <tr class="HeadTable">
                          <td width="10%" colspan="1" height="21" align="center">
                                  <input type="checkbox" name="chkBox" />
                                  <input type="checkbox" name="chkBox" disabled="disabled" />
                          </td>
                          <td width="10%" colspan="1" height="21" align="left">DocSet ID</td>
                          <td width="20%" colspan="1" height="21" align="left">Batch Name</td>
                          <td width="15%" colspan="1" height="21" align="left">Batch Date</td>
                          <td width="10%" colspan="1" height="21" align="left">No. Of Doc.</td>
                          <td width="15%" colspan="1" height="21" align="left">No. Of Copies</td>			
                          <td width="20%" colspan="1" height="21" align="left">SortKey</td>			
                      </tr>
                          <tr>
                              <td width="10%" colspan="1" height="21" align="center"><input type="checkbox" name="docSetPrintChk" value="" /></td>
                              <td width="10%" colspan="1" height="21" align="left">docSetId</td>
                              <td width="20%" colspan="1" height="21" align="left">batchName</td>
                              <td width="15%" colspan="1" height="21" align="left">batchDate</td>
                              <td width="10%" colspan="1" height="21" align="left">totalDocuments</td>
                              <td width="15%" colspan="1" height="21" align="left">noOfCopies</td>				
                              <td width="20%" colspan="1" height="21" align="left">sortKey</td>				
                          </tr>
                          <tr>
                              <td width="100%" colspan="7">&nbsp;</td>
                          </tr>					
                          <tr>
                              <td width="100%" colspan="7" align="center">
                                      <input type="button" class="btn btn-primary" name="ListDoc" value="ListDoc" />
                                      <input type="button" class="btn btn-primary" name="Print" value="Print" />		
                              </td>
                          </tr>
                          <tr>
                              <td width="100%" colspan="7">&nbsp;</td>
                          </tr>
                          
                          <tr class="body">
                              <td width="100%" colspan="7" height="21" align="center" class="HeadBold">recordsNotFound!...</td>
                          </tr>				
                    </tbody>
                  </table>	
                    <table cellSpacing="1" cellPadding="1" width="100%" align="center" border="0">
                     <tbody>
                            <tr class="HeadTable">
                              <td width="8%" colspan="1" height="21" align="center">
                                      <input type="checkbox" name="chkBox" />				
                                      <input type="checkbox" name="chkBox" disabled="disabled" />
                              </td>
                              <td width="9%" colspan="1" height="21" align="left">DocID</td>
                              <td width="9%" colspan="1" height="21" align="left">DocSet ID</td>
                              <td width="15%" colspan="1" height="21" align="left">Batch Name</td>
                              <td width="15%" colspan="1" height="21" align="left">Batch Date</td>
                              <td width="15%" colspan="1" height="21" align="left">Attribute</td>
                              <td width="15%" colspan="1" height="21" align="left">Attribute</td>
                              <td width="15%" colspan="1" height="21" align="left">LetterType</td>	
                          </tr>
                              <tr>
                                  <td width="8%" colspan="1" height="21" align="center"><input type="checkbox" name="docSetPrintChk" value="" /></td>
                                  <td width="9%" colspan="1" height="21" align="left">docId</td>
                                  <td width="9%" colspan="1" height="21" align="left">docSetId</td>
                                  <td width="15%" colspan="1" height="21" align="left">batchName</td>
                                  <td width="15%" colspan="1" height="21" align="left">batchDate</td>
                                  <td width="15%" colspan="1" height="21" align="left">attribute1</td>
                                  <td width="15%" colspan="1" height="21" align="left">attribute2</td>
                                  <td width="15%" colspan="1" height="21" align="left">letterType</td>
                              </tr>
                              <tr>
                                  <td width="100%" colspan="8">&nbsp;</td>
                              </tr>
                              <tr>
                                  <td width="100%" colspan="8" align="center">
                                          <input type="button"  class="btn btn-primary" name="Back" value="Back" />		
                                          <input type="button"  class="btn btn-primary" name="Print" value="Print" />			
                                  </td>
                              </tr>
                              <tr>
                                  <td width="100%" colspan="8">&nbsp;</td>
                              </tr>
                              <tr class="body">
                                  <td width="100%" colspan="8" height="21" align="center" class="HeadBold">recordsNotFound!...</td>
                              </tr>
                      </tbody>
                     </table>
              </td>
                <Td width="1" bgColor="#0066ce"><IMG height="1" src="images/dsPrint/spacer.gif" width="1" /></Td>
           </tr>
           <tr>
                <TD width="1" bgColor="#0066ce"><IMG height="1" src="images/dsPrint/spacer.gif" width="1" /></TD>
                <TD bgColor="#0066ce" colSpan="6"><IMG height="1" src="images/dsPrint/spacer.gif" width="1" /></TD>
                <TD width="1" bgColor="#0066ce"><IMG height="1" src="images/dsPrint/spacer.gif" width="1" /></TD>
           </tr>
           </tbody>
          </table>
      </form>

            </div>
                    );
    }
}

export default ErrorDocForPrint;
