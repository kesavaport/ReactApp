import React, { Component } from 'react';

class DocumentListSelection extends Component {
    render() {
        return (
            <tr className="body">
                <td width="5% " colSpan="1 " height="21 " align="center "><input type="checkbox" name="chkBox" /></td>
                <td width="8% " colSpan="1 " height="21 " align="left ">13</td>
                <td width="8% " colSpan="1 " height="21 " align="left ">10</td>
                <td width="15% " colSpan="1 " height="21 " align="left ">AWPL</td>
                <td width="12% " colSpan="1 " height="21 " align="left ">Batch Date</td>
                <td width="15% " colSpan="1 " height="21 " align="left ">Main Document</td>
                <td width="15% " colSpan="1 " height="21 " align="left ">Sub Document</td>
                <td width="13% " colSpan="1 " height="21 " align="left ">BlankPage</td>
                <td width="10% " colSpan="1 " height="21 " align="left ">To be Printed</td>
            </tr>
        );
    }
}

export default DocumentListSelection;
