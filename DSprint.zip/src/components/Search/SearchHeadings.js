import React, { Component } from 'react';

class SearchHeadings extends Component {
    render() {
        return (

            <tr className="HeadBold" bgcolor="#0066ce">
                <td height="21" width="40%">&nbsp;&nbsp; Column Name </td>
                <td height="21" width="20%"> Operator </td>
                <td height="21" width="40%"> Column Value</td>
                <td width="100%" colSpan="3" height="21">&nbsp;</td>
            </tr>

        );
    }
}

export default SearchHeadings;
