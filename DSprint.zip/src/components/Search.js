import React, { Component } from 'react';
import SearchHeader from './../components/Search/SearchHeader';
import SearchHeadings from './../components/Search/SearchHeadings';
import SeachBatch from './../components/Search/SeachBatch';
import SeachType from './../components/Search/SeachType';
import SearchBatchDate from './../components/Search/SearchBatchDate';
import SearchBottons from './../components/Search/SearchBottons';
import SearchDocCatagory from './../components/Search/SearchDocCatagory';
import SearchDocSetId from './../components/Search/SearchDocSetId';
import SearchShortKey from './../components/Search/SearchShortKey';

class RedirectPage extends Component {
    render() {
        return (
            
            <div >
                <br />
                <br />
                <br />
                <br />
                <form className="body container4 card">
                    <br />
                    <br />
                    <table cellSpacing="0" cellPadding="0" width="60%" align="center" border="0">
                        <tbody>
                            <SearchHeader />
                            <tr>
                                <td width="1" bgcolor="#0066ce">
                                    <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                                </td>
                                <td width="100%" colSpan="3">
                                    <table cellSpacing="0" cellPadding="0" width="100%" align="center" border="0">
                                        <tbody>
                                            <tr className="body">
                                                <td width="100%" colSpan="3" height="21">&nbsp;</td>
                                            </tr>
                                            <SeachBatch />
                                            <SearchDocCatagory />
                                            <SeachType />
                                            <tr className="body">
                                                <td width="100%" colSpan="3" height="50">&nbsp;</td>
                                            </tr>

                                            <SearchHeadings />
                                            <SearchDocSetId />
                                            <SearchBatchDate />
                                            <SearchShortKey />
                                            <tr className="body">
                                                <td width="100%" colSpan="3" height="23">&nbsp;</td>
                                            </tr>
                                            <SearchBottons />
                                            <tr className="body">
                                                <td width="100%" colSpan="3" height="23">&nbsp;</td>
                                            </tr>
                                            <tr className="body">
                                                <td width="100%" bgcolor="#0066ce" colSpan="4">
                                                    <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                                <td width="1" bgcolor="#0066ce">
                                    <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </form>
            </div>

        );
    }
}

export default RedirectPage;
