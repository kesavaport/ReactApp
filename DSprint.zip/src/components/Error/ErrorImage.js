import React, { Component } from 'react';
//import BackImage from '../images/dsPrint/Back.gif';
import BackImage from '../../images/dsPrint/Back.gif';
class ErrorImage extends Component {
    render() {
        return (
            <tr className="body">
                <td width="100%" colSpan="2" height="23" align="center">
                    <img src={`${BackImage}`} /> </td>
            </tr>
        );
    }
}

export default ErrorImage;
