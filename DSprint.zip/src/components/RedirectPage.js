import React, { Component } from 'react';

class RedirectPage extends Component {
    render() {
        return (
            <div>
            <script language="JavaScript">
               {alert("Hii")};
            </script>
            </div>
        );
    }
}

export default RedirectPage;
