import React, { Component } from 'react';

class UserInfoListHeadings extends Component {
    render() {
        return (
            <tr className="HeadTable">
                <td width="15%" colSpan="1" height="21" align="center">Select</td>
                <td width="85%" colSpan="1" height="21" align="left">Username</td>
            </tr>
        );
    }
}

export default UserInfoListHeadings;
