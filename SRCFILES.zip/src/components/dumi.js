<ul id="nav-mobile" className="right hide-on-med-and-down">
  <li><a to="/">Home</a></li>
  <li><a to="/decisionchecklist">Decision Checklist Component </a></li>

  <li><a to="/remarks">Remarks Component</a></li>
  <li><a to="/reduxapp">Redux Application</a></li>
</ul>