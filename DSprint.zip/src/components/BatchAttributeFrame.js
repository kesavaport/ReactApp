import React, { Component } from 'react';
//import BatchAttributeFrame from './BatchAttributeFrame/BatchFrame';
import BatchHeader from './BatchAttributeFrame/BatchHeader';
import BatchFrame from './BatchAttributeFrame/BatchFrame';

class BatchAttributeFrame extends Component {
    render() {
        return (
            <div className="BatchAttributeFrame">
               
               <BatchHeader />
               <BatchFrame />
            </div>
        );
    }
}
export default BatchAttributeFrame;