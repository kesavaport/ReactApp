import React, { Component } from 'react';

class ErrorDocForPrintData extends Component {
    render() {
        return (
                <tr className="body">
                    <td width="10%" colSpan="1" height="21" align="center"><input type="checkbox" name="docSetPrintChk" value="" /></td>
                    <td width="10%" colSpan="1" height="21" align="left">11</td>
                    <td width="20%" colSpan="1" height="21" align="left">AWPL</td>
                    <td width="15%" colSpan="1" height="21" align="left">2017-08-08</td>
                    <td width="10%" colSpan="1" height="21" align="left">1+3</td>
                    <td width="15%" colSpan="1" height="21" align="left">1</td>
                    <td width="20%" colSpan="1" height="21" align="left">POLICYNUMBER</td>
                </tr>
                
        );
    }
}

export default ErrorDocForPrintData;
