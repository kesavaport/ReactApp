import React, { Component } from 'react';

class UserInfoEntryPassword extends Component {
    render() {
        return (
            <tr className="body">
                <td width="20%" colSpan="1" height="21" align="left">&nbsp;Password</td>

                <td width="40%" colSpan="1" height="21" align="left">&nbsp;
                <input type="password" name="userInfoVO" id="password" size="15" style={{ border: "" }} className="inps" />
                </td>
                <td width="40%" colSpan="1" height="21" align="left"></td>
            </tr>

        );
    }
}

export default UserInfoEntryPassword;
