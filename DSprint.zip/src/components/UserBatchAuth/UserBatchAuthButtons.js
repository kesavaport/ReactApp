import React, { Component } from 'react';
import { Link } from 'react-router-dom';
class UserBatchAuthButtons extends Component {
    render() {
        return (
            <tr className="body">
                <td width="100%" colSpan="4" height="21" align="center">
                    <Link to=""><input type="button" name="Ok" value="Ok" className="btn btn-primary" /></Link>&nbsp;
                <Link to="BatchListForAuthorization"><input type="button" name="Cancel" value="Cancel" className="btn btn-primary" /></Link>
                </td>
            </tr>
        );
    }
}

export default UserBatchAuthButtons;
