import React, { Component } from 'react';
import './App.css';
import {
    BrowserRouter,
    Route,
    Link,
    Switch,
    NavLink
} from 'react-router-dom';
import { HomeComponent } from "./components/HomeComponent";
import { RemarksComponent } from "./components/remarksPage/RemarksComponent"; 
import { DecisionChecklistComponent } from "./components/decisionpage/DecisionChecklistComponent";
import { ReduxApplication } from "./components/ReduxApplication";
const styles = {
    backgroundImage: {
        backgroundImage: "url(./assets/icon-seamless.png)",
        
        backgroundColor: "#3f51b5"
    },

}

class App extends Component {

    render() {
        // console.log(this.props.geod)
        return (
            <BrowserRouter>
            <div style={styles.backgroundImage} className="appHold">
                <div className="container">
                    <nav>
                        <div className="nav-wrapper">
                            <a className="brand-logo">Logo</a>
                            <ul id="nav-mobile" className="right hide-on-med-and-down" style={{height:"inherit"}}>
                                <li><Link to="/home" >Home</Link><br /></li>
                                <li><Link to="/decisionchecklist" >Decision Checklist</Link></li>

                                <li><Link to="/remarks" >Remarks</Link></li>
                                <li><Link to="/reduxapp" >Reduxapp</Link></li>
                            </ul><br/>
                            
                                <div>
                                    <Switch>
                                        <Route path="/" exact component={HomeComponent} />
                                        <Route path="/home" component={HomeComponent} />
                                        <Route path="/decisionchecklist" component={DecisionChecklistComponent} />
                                        <Route path="/remarks" component={RemarksComponent} />
                                        <Route path="/reduxapp" component={ReduxApplication} />
                                    </Switch>
                                </div>
                            
                        </div>
                    </nav>

                </div>


            </div>
            </BrowserRouter>
        );
    }
}


export default App;

export const Header = () => (
    <header style={{ color: "#000" }}>


    </header>
);