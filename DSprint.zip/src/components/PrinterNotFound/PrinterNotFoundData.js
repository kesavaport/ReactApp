import React, { Component } from 'react';
class PrinterNotFoundData extends Component {
    render() {
        return (
            <div className="container card">
            <tr>
                <td colSpan="2" width="100%">
                    <center>No printers found in the network..</center>
                </td>
            </tr>
            </div>
        );
    }
}

export default PrinterNotFoundData;
