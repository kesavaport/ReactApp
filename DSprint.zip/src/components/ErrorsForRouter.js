import React, { Component } from 'react';
import VPLoggedPage from './VPLoggedPage';
import ErrorsForRouterHeader from './ErrorsForRouter/ErrorsForRouterHeader';
import ErrorsForRouterHeadings from './ErrorsForRouter/ErrorsForRouterHeadings';
import ErrorsForRouterData from './ErrorsForRouter/ErrorsForRouterData';
import ErrorsForRouterButton from './ErrorsForRouter/ErrorsForRouterButton';
class ErrorsForRouter extends Component {
    render() {
        return (
            <div className="body">
            
              <VPLoggedPage />
            
                <br />
                <form>
                    <table cellSpacing="0" cellPadding="0" width="100%" align="center" border="0">

                        <tbody>
                            <ErrorsForRouterHeader />
                            <tr>
                                <td width="1" bgcolor="#0066ce">
                                    <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                                </td>
                                <td width="100%" id="errorList">
                                    <table cellSpacing="1" cellPadding="1" width="100%" align="center" border="0">
                                        <tbody>
                                            <ErrorsForRouterHeadings />
                                            <ErrorsForRouterData />
                                            <tr className="body">
                                                <td width="5%" colSpan="1" height="21" align="center">
                                                    <input type="checkbox" name="docSetPrintChk" value="" />
                                                </td>
                                                <td width="17%" colSpan="1" height="21" align="left">NB</td>
                                                <td width="12%" colSpan="1" height="21" align="left">2017/12/23</td>
                                                <td width="20%" colSpan="1" height="21" align="left">a@a.com</td>
                                                <td width="13%" colSpan="1" height="21" align="left">12345</td>
                                                <td width="33%" colSpan="1" height="21" align="left">testing error</td>
                                            </tr>
                                            <tr>
                                                <td width="100%" colSpan="6">&nbsp;</td>
                                            </tr>
                                            <ErrorsForRouterButton />

                                            <tr className="body">
                                                <td width="100%" colSpan="6" height="21" align="center" className="HeadBold">NoRecFound</td>
                                            </tr>
                                            <tr>
                                                <td width="100%" colSpan="6">&nbsp;</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                                <td width="1" bgcolor="#0066ce">
                                    <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                                </td>
                            </tr>
                            <tr>
                                <td width="1" bgcolor="#0066ce">
                                    <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                                </td>
                                <td width="100%" bgcolor="#0066ce">
                                    <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                                </td>
                                <td width="1" bgcolor="#0066ce">
                                    <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </form>
            </div>

        );
    }
}

export default ErrorsForRouter;
