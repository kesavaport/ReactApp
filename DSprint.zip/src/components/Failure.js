import React, { Component } from 'react';

class Failure extends Component {
    render() {
        return (
            <div className="body">
                <script language="JavaScript">
                    {alert("Hii")};
            </script>
            </div>
        );
    }
}

export default Failure;
