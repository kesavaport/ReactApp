import React, { Component } from 'react';

class PrinterHeadings extends Component {
    render() {
        return (
            <tr className="HeadTable">
                <td width="10%" colSpan="1" height="21" align="center" className="HeadBold" bgcolor="#0066ce">Select</td>
                <td width="90%" colSpan="1" height="21" align="left" className="HeadBold" bgcolor="#0066ce">Printers</td>
            </tr>
        );
    }
}

export default PrinterHeadings;
