import React, { Component } from 'react';

class AdminRolesBatchAttributes extends Component {
  render() {
    return (
        <tr>
          <td height="35" width="100">
             <input type="button" name="batchAtt" value="Batch Attributes" className="btn btn-primary" />
          </td>
        </tr>
    );
  }
}

export default AdminRolesBatchAttributes;