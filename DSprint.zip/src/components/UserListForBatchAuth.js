import React, { Component } from 'react';
import UserListForBatchAuthHeader from './UserListForBatchAuth/UserListForBatchAuthHeader';
import UserListForBatchAuthHeadings from './UserListForBatchAuth/UserListForBatchAuthHeadings';
import UserListForBatchAuthData from './UserListForBatchAuth/UserListForBatchAuthData';
import UserListForBatchAuthMsg from './UserListForBatchAuth/UserListForBatchAuthMsg';

class UserListForBatchAuth extends Component {
    render() {
        return (
            <div>
                <form>
                    <br />
                    <br />
                    <table cellSpacing="0" cellPadding="0" width="100%" align="center" border="0">
                        <tbody>
                            <UserListForBatchAuthHeader />
                            <tr>
                                <td width="1" bgcolor="#0066ce"><img height="1" src="images/dsPrint/spacer.gif" width="1" /></td>
                                <td width="100%" colSpan="3" >
                                    <table cellSpacing="1" cellPadding="1" width="100%" align="center" border="0">
                                        <tbody>
                                            <UserListForBatchAuthHeadings />
                                            <UserListForBatchAuthData />
                                            <tr>
                                                <td width="100%" colSpan="3">&nbsp;</td>
                                            </tr>
                                            <UserListForBatchAuthMsg />
                                            <tr>
                                                <td width="100%" colSpan="3">&nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td width="100%" colSpan="3">&nbsp;</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                                <td width="1" bgcolor="#0066ce"><img height="1" src="images/dsPrint/spacer.gif" width="1" /></td>
                            </tr>
                            <tr>
                                <td width="1" bgcolor="#0066ce"><img height="1" src="images/dsPrint/spacer.gif" width="1" /></td>
                                <td bgcolor="#0066ce" colSpan="3"><img height="1" src="images/dsPrint/spacer.gif" width="1" /></td>
                                <td width="1" bgcolor="#0066ce"><img height="1" src="images/dsPrint/spacer.gif" width="1" /></td>
                            </tr>
                        </tbody>
                    </table>
                </form>
            </div>
        );
    }
}

export default UserListForBatchAuth;