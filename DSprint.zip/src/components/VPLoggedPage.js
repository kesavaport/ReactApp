import React, { Component } from 'react';
import { BrowserRouter, Route, Switch, Link, NavLink } from 'react-router-dom';
import Home from '../images/dsPrint/home.gif';
import Search from '../images/dsPrint/Search.gif';
import ErrorDoc from '../images/dsPrint/Error-Doc.gif';
import RouterError from '../images/dsPrint/RouterError.gif';
import Admin from '../images/dsPrint/Admin.gif';
import Logout from '../images/dsPrint/Logout.gif';
import DotSpherePrintLogo from '../images/dsPrint/DotSpherePrint_Logo.gif';
import DotSphereLogo from '../Dotsphere.gif';
import userIcon from '../images/ImagesHeader/userIcon.gif';
class VPLoggedPage extends Component {
    render() {
        return (
            <div className="body">
            <form>
            <br />
            <br />
            <table cellSpacing="0" cellPadding="0" width="100%" align="center" border="0">
                <tbody>
                    <tr> 
                        <td width="1" className="body" width="1" height="23" bgcolor="#0066ce"></td>
                        <td width="102%" colSpan="3" align="left" className="HeadBold" bgcolor="#0066ce">&nbsp; Logged Page</td>
                        <td width="1" width="1" height="23" bgcolor="#0066ce"></td>
                    </tr>
            </tbody>
            </table>
            <table width="100%" border="0" cellSpacing="0" cellPadding="0">
            <tbody>
                <tr>
                    <td width="1" height="1"><img src="images/ImagesHeader/spacer.gif" width="1" height="1" /></td>
                </tr>
            </tbody>
            </table>
            <table width="100%" border="0" cellPadding="0" cellSpacing="0" background={DotSphereLogo}>
            <tbody>
                <tr>
                    <td width="257">&nbsp;</td>
                    <td bgcolor="#FFFFFF" align="center"><img src={`${DotSpherePrintLogo}`} name="Image12" width="168" height="41" border="0" /></td>
                    <td bgcolor="#FFFFFF" align="right">
                        <table border="0" align="right" cellPadding="0" cellSpacing="0">
                        <tbody>
                            <tr>
                               <td bgcolor="#FFFFFF"> <Link to="/home">
                                    <img src={`${Home}`} name="Image81" width="49" height="37" border="0" /></Link></td>
                                <td><Link to="/Search">
                                    <img src={`${Search}`} name="Image82" width="47" height="41" border="0" /></Link></td>
                                <td><Link to="/ErrorDoc">
                                    <img src={`${ErrorDoc}`} name="Image83" width="58" height="41" border="0" /></Link></td>
                                <td><Link to="/RouterError">
                                    <img src={`${RouterError}`} name="Image86" width="77" height="41" border="0" /></Link></td>
                                <td><Link to="/AdminRouting">
                                    <img src={`${Admin}`} name="Image85" width="47" height="41" border="0" /></Link></td>
                                <td><Link to="/Logout">
                                    <img src={`${Logout}`} name="Image84" width="47" height="41" border="0" /></Link></td>
                               
                            </tr>
                        </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>    
            </table>
            <table width="100%" border="0" cellPadding="0" cellSpacing="0">
            <tbody>
                <tr>
                    <td width="15" height="13" bgcolor="0066ce"><img src={`${userIcon}`} width="15" height="13" /></td>
                    <td width="458" height="13" bgcolor="0066ce" className="body HeadBold">VPUserName</td>
                    <td height="13" bgcolor="0066ce" width="458">&nbsp;</td>
                </tr>
            </tbody>
            </table>
            </form>
        </div>
        );
    }
}

export default VPLoggedPage;
