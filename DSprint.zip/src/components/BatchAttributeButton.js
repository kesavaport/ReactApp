import React, {Component} from 'react';
import BatchAttributeButtonCss from './BatchAttributeButton/BatchAttributeButtonCss';
import BatchButtons from './BatchAttributeButton/BatchButtons';
class BatchAttributeButton extends Component{
    render(){
        return (
            <div className = "BatchAttributeButton">
              <BatchAttributeButtonCss />
              <BatchButtons />
            </div>
        );
    }
}
export default BatchAttributeButton;