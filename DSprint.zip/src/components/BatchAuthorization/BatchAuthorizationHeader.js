import React, { Component } from 'react';

class BatchAuthorizationHeader extends Component {
    render() {
        return (
            <tr className="BatchAuthorizationHeader">
                <td width="1" className="body" width="1" height="23" bgcolor="#0066ce"></td>
                <td width="102%" colSpan="4" align="left" className="HeadBold" bgcolor="#0066ce">&nbsp; Batch List For Allocation - (icmadmin)</td>
                <td width="1" width="1" height="23" bgcolor="#0066ce"></td>
            </tr>
        );
    }
}

export default BatchAuthorizationHeader;
