import React, { Component } from 'react';

class DocumentListHeadings extends Component {
    render() {
        return (
            <tr className="HeadTable">
                <td width="5%" colSpan="1" height="21" align="center">
                    <input type="checkbox" name="chkBox" />
                   
                </td>
                <td width="10% " colSpan="1 " height="21 " align="left ">Document ID</td>
                <td width="10% " colSpan="1 " height="21 " align="left ">DocSet ID</td>
                <td width="10% " colSpan="1 " height="21 " align="left ">Batch Name</td>
                <td width="10% " colSpan="1 " height="21 " align="left ">Batch Date</td>
                <td width="10% " colSpan="1 " height="21 " align="left ">Attribute1</td>
                <td width="10% " colSpan="1 " height="21 " align="left ">Attribute2</td>
                <td width="15% " colSpan="1 " height="21 " align="left ">Letter Type</td>
                <td width="20% " colSpan="1 " height="21 " align="left ">Print Status</td>
            </tr>
        );
    }
}

export default DocumentListHeadings;
