import React, { Component } from 'react';
import {  Link } from 'react-router-dom';
class DeleteDocsFromBatchListButtons extends Component {
    render() {
        return (
           
            <table cellSpacing="0" cellPadding="0" width="100%" align="center" border="0" className="body">
             <tbody>
                  <tr>
                    <td width="100%" colSpan="3" align="center">
                        <Link to="Deleted"><input type="button" name="Delete" value="Delete" className="btn btn-primary inps" /></Link>&nbsp;
                        <Link to="DeleteDocsFromBatchList"><input type="button" name="Cancel" value="Cancel" className="btn btn-primary inps" /></Link>&nbsp;
                    </td> 
                  </tr>
              </tbody>
            </table>
           
        );
    }
}

export default DeleteDocsFromBatchListButtons;
