import React, {Component} from 'react';

class BatchButtons extends Component{
    render(){
        return (
            <div className = "BatchButtons">
            <form>
            <br />
            <br />
            <table cellSpacing="0" cellPadding="0" width="100%" align="center" border="0">
              <tbody>
                  <tr>
                      <td width="100%" colSpan="3" align="center">
                        <input type="button" name="Update" value="Update" class="btn btn-primary inps" />&nbsp;
                        <input type="button" name="Delete" value="Delete" class="btn btn-primary inps" />&nbsp;
                        <input type="button" name="Add" value="Add" class="btn btn-primary inps" />&nbsp;
                    </td>
                  </tr>
              </tbody>
            </table>
            </form>
              
            </div>
        );
    }
}
export default BatchButtons;
