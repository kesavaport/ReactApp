import React from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter, Route, Switch, Link, NavLink } from 'react-router-dom';
import BatchList from '../components/BatchList';
import UserInfoList from '../components/UserInfoList';
import BatchAttributeList from '../components/BatchAttributeList';
import DeleteDocsFromBatchList from '../components/DeleteDocsFromBatchList';
import UserListForBatchAuth from '../components/UserListForBatchAuth';
import BatchInfo from '../components/BatchInfo';
import Success from '../components/Success';
import BatchAttributeInfo from '../components/BatchAttributeInfo';
import SuccessAttribute from '../components/SuccessAttribute';
import SuccessUser from '../components/SuccessUser';
import VPLoggedPage from '../components/VPLoggedPage';
import UserInfoEntry from '../components/UserInfoEntry';
import BatchListForAuthorization from '../components/BatchListForAuthorization';
import UserBatchAuth from '../components/UserBatchAuth';
import DeleteDocsFromDocSetList from '../components/DeleteDocsFromDocSetList';
import DeleteDocs from '../components/DeleteDocs';
import DeleteAlert from '../components/DeleteDocs/DeleteAlert';
//======Tree
import Tree, { TreeNode } from 'rc-tree';
import 'rc-tree/assets/index.css';

const Header = () => (

    <div className="container1">
     
      <Tree defaultExpandAll showLine >
      <TreeNode title="Admin" key="0-1">
          <TreeNode title={<NavLink to="/AdminRouting">Batches</NavLink>} />
          <TreeNode title={<NavLink to="/BatchAttributeList">Batch Attributes</NavLink>} />
          <TreeNode title={<NavLink to="/user">Users</NavLink>} />
          <TreeNode title={ <NavLink to="/UserListForBatchAuth">Batch Allocation</NavLink>} />
          <TreeNode title={<NavLink to="/DeleteDocsFromBatchList">Delete Documents</NavLink>} />
          <TreeNode title={<NavLink to="/xyz">xyz</NavLink>} />
      </TreeNode>
      </Tree>
    </div>

)
const AdminRouting = () => (

    
    <BrowserRouter>
    <div id="wrap">
    <Header />
    <div className="container2">
        <Switch>
          <Route path= "/AdminRouting" exact={true} component = {BatchList} />
          <Route path= "/user"  component = {UserInfoList} />
          <Route path= "/BatchAttributeList"  component = {BatchAttributeList} />
          <Route path= "/DeleteDocsFromBatchList"  component = {DeleteDocsFromBatchList} />
          <Route path= "/UserListForBatchAuth"  component = {UserListForBatchAuth} />
          <Route path= "/BatchInfo"  component = {BatchInfo} />
          <Route path= "/Success"  component = {Success} />
          <Route path= "/SuccessAttribute"  component = {SuccessAttribute} />    
          <Route path= "/BatchAttributeInfo"  component = {BatchAttributeInfo} />
          <Route path= "/UserInfoEntry"  component = {UserInfoEntry} />
          <Route path= "/SuccessUser"  component = {SuccessUser} />
          <Route path= "/BatchListForAuthorization"  component = {BatchListForAuthorization} />
          <Route path= "/UserBatchAuth"  component = {UserBatchAuth} />
          <Route path= "/DeleteDocsFromDocSetList"  component = {DeleteDocsFromDocSetList} />
          <Route path= "/DeleteDocs"  component = {DeleteDocs} />
          <Route path= "/Deleted"  component = {DeleteAlert} />
          <Route path= "/xyz"  component = {UserInfoList} />
        </Switch>
        </div>
        </div>
       </BrowserRouter>
         
);

export default AdminRouting;

//ReactDOM.render(routes, document.getElementById('app'));

