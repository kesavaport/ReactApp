import React, { Component } from 'react';

class ErrorDocumentsForPrintData extends Component {
    render() {
        return (
            <tr className="body">
                <td width="8%" colSpan="1" height="21" align="center"><input type="checkbox" name="docSetPrintChk" value="" /></td>
                <td width="9%" colSpan="1" height="21" align="left">16</td>
                <td width="9%" colSpan="1" height="21" align="left">11</td>
                <td width="15%" colSpan="1" height="21" align="left">AWPL</td>
                <td width="15%" colSpan="1" height="21" align="left">Batch Date</td>
                <td width="15%" colSpan="1" height="21" align="left">Main Document</td>
                <td width="15%" colSpan="1" height="21" align="left">Sub Document</td>
                <td width="15%" colSpan="1" height="21" align="left"></td>
            </tr>

        );
    }
}

export default ErrorDocumentsForPrintData;
