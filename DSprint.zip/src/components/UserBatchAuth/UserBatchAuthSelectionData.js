import React, { Component } from 'react';

class UserBatchAuthSelectionData extends Component {
    render() {
        return (
            <tr className="body">
                <td width="30%" colSpan="1" height="21" align="left">&nbsp;
                <input type="text" name="cnt" value="1" readOnly="readOnly" size="1" className="inps" />&nbsp;&nbsp;</td>
                <td width="30%" colSpan="1" height="21" align="left">
                    <select id="columnName">
                        <option value="">Select Attribute</option>
                        <option collection="colList" id="columnName" />
                    </select>
                </td>
                <td width="20%" colSpan="1" height="21" align="left">
                    <select name="operator">
                        <option value="">Select</option>
                        <option value="=">=</option>
                        <option value="<>"> v </option>
                    </select>
                </td>
                <td width="20%" colSpan="1" height="21" align="left">
                    <input type="text" name="filter" size="15" />
                </td>
            </tr>
        );
    }
}

export default UserBatchAuthSelectionData;
