import React, { Component } from 'react';
import RemoveImg from '../../images/dsPrint/Delete_img.gif';
import {  Link, NavLink } from 'react-router-dom';
class BatchAuthorizationStatus extends Component {
    render() {
        return (
        
            <tr className ="BatchAuthorizationStatus body">
                <td width="15%" colSpan="1" height="21" align="center">1</td>
                <td width="35%" colSpan="1" height="21" align="left"><NavLink to="/UserBatchAuth">AWPL</NavLink></td>
                <td width="30%" colSpan="1" height="21" align="left">Assigned</td>
                <td width="20%" colSpan="1" height="21" align="center">
                    <a href="username" ><img src={RemoveImg} border="0" name="Image7" width="16" height="16" /></a>
                </td>
            </tr>
           
       
        );
    }
}

export default BatchAuthorizationStatus;
