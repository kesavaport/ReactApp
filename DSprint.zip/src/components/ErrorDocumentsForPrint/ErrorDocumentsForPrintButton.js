import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import Printer from '../Printer'
import ErrorDoc from '../ErrorDocForPrint';

class ErrorDocumentsForPrintButton extends Component {
    render() {
        return (
            <tr>
                <td width="100%" colSpan="8" align="center">
                    <Link to="/ErrorDoc"><input type="button" className="btn btn-primary" name="Back" value="Back" /></Link>&nbsp;
                    <Link to="/Printer">  <input type="button" className="btn btn-primary" name="Print" value="Print" /></Link>&nbsp;
                </td>
            </tr>

        );
    }
}

export default ErrorDocumentsForPrintButton;
