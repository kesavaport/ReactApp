import React, { Component } from 'react';
import BatchAttributeInfoHeader from './BatchAttributeInfo/BatchAttributeInfoHeader';
import BatchAttributeInfoAttributeName from './BatchAttributeInfo/BatchAttributeInfoAttributeName';
import BatchAttributeInfo_AttributeDescription from './BatchAttributeInfo/BatchAttributeInfoAttributeDescription';
import BatchAttributeInfoButtons from './BatchAttributeInfo/BatchAttributeInfoButtons';
class BatchAttributeInfo extends Component {
    render() {
        return (
            <div className="BatchAttributeInfo">
                <form>
                    <br />
                    <br />
                    <table cellSpacing="0" cellPadding="0" width="100%" align="center" border="0">
                        <tbody>
                            <BatchAttributeInfoHeader />
                            <tr>
                                <td width="1" bgcolor="#0066ce"><img height="1" src="images/dsPrint/spacer.gif" width="1" /></td>
                                <td width="100%" colSpan="3" >
                                    <table cellSpacing="0" cellPadding="0" width="100%" align="center" border="0">
                                        <tbody>
                                            <tr className="body">
                                                <td width="100%" colSpan="3" height="21">&nbsp;</td>
                                            </tr>

                                            <BatchAttributeInfoAttributeName />

                                            <BatchAttributeInfo_AttributeDescription />

                                            <tr className="body">
                                                <td width="100%" colSpan="3" height="21">&nbsp;</td>
                                            </tr>

                                           <BatchAttributeInfoButtons />

                                            <tr className="body">
                                                <td width="100%" colSpan="3" height="23">&nbsp;</td>
                                            </tr>

                                            <tr className="body">
                                                <td width="100%" bgcolor="#0066ce" colSpan="3"><img height="1" src="images/dsPrint/spacer.gif" width="1" /></td>
                                            </tr>

                                        </tbody>
                                    </table>
                                </td>
                                <td width="1" bgcolor="#0066ce"><img height="1" src="images/dsPrint/spacer.gif" width="1" /></td>
                            </tr>
                        </tbody>
                    </table>
                </form>
            </div>
        );
    }
}
export default BatchAttributeInfo;