import React, { Component } from 'react';

class VPSuccessLoginFrame extends Component {
    render() {
        return (
            <frameset rows="85,*" framespacing="0" border="0">
                <frame src="" name="FRAME_HEADER" frameborder="0" scrolling="no" noresize="noresize" />
                <frame src="" name="FRAME_ROLES" frameborder="0" scrolling="auto" />
            </frameset>
        );
    }
}

export default VPSuccessLoginFrame;
