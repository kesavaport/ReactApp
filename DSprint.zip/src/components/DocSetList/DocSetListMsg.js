import React, { Component } from 'react';

class DocSetListMsg extends Component {
    render() {
        return (
            <tr className="body">
                <td width="100%" colSpan="6" height="21" align="center" className="HeadBold">noRecord</td>
            </tr>
        );
    }
}

export default DocSetListMsg;
