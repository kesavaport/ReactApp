import React, {Component} from 'react';

class BatchHeader extends Component {
    render(){
        return(
           <div className="BatchFrame">
           <head>
           <title>DSPrint</title>
          </head>
           </div>
        );
    }
}
export default BatchHeader;