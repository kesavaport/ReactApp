import React from 'react';
import { BrowserRouter, Route, Switch, Link, NavLink } from 'react-router-dom';
import LoginComponent from './../components/LoginComponent';
import VelociPrintLogin from './../components/VelociPrintLogin';
import VPLoggedPage from './../components/VPLoggedPage';
import Search from './../components/Search';
import ErrorDoc from './../components/ErrorDocForPrint';
import RouterError from './../components/ErrorsForRouter';
import DocSetList from './../components/DocSetList';
import DocumentList from './../components/DocumentList';
import Printer from './../components/Printer';
import ErrorDocumentsForPrint from '../components/ErrorDocumentsForPrint';
import PrintingAlert from '../components/Printer/PrintingAlert';
import DisplayRouting from '../routers/DisplayRouting';

const AppRouter = () => (

    
       <BrowserRouter>
       <div> 
        <Switch>
          <Route path= "/" exact={true} component = {VelociPrintLogin} />
          <Route path= "/AdministratorLogin" component = {VelociPrintLogin} />
          <Route path= "/LoginPage" component = {LoginComponent} />
          <Route path= "/VPLoggedPage" component = {VPLoggedPage} />
          <Route path= "/home" component = {DocSetList} />
          <Route path= "/Search" component = {Search} />
          <Route path= "/ErrorDoc" component = {ErrorDoc} />
          <Route path= "/RouterError" component = {RouterError} />
          <Route path= "/Admin" component = {VelociPrintLogin} />
          <Route path= "/Logout" component = {VelociPrintLogin} />
          <Route path= "/DocSetList" component = {DocSetList} />
          <Route path= "/DocumentList" component = {DocumentList} />
          <Route path= "/Printer" component = {Printer} />
          <Route path= "/ErrorDocumentsForPrint" component = {ErrorDocumentsForPrint} />
          <Route path= "/Printing"  component = {PrintingAlert} />
          <Route path= "/AdminRouting" component = {DisplayRouting} />
        </Switch>
        </div>
       </BrowserRouter>
    
);

export default AppRouter;
