import React, { Component } from 'react';

class UserInfoFrame extends Component {
    render() {
        return (
            <frameset rows="*,70" cols="*" framespacing="0" border="0">
            <frame src="UserInfoButton.html" name="FRAME_PRINT_BOTTOM" frameborder="0" scrolling="no"  />
            </frameset>
        );
    }
}

export default UserInfoFrame;
