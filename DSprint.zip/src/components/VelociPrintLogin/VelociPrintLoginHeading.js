import React, { Component } from 'react';

class VelociPrintLoginHeading extends Component {
    render() {
        return (
            <tr>
                <td width="1" className="body" width="1" height="23"></td>
                <td width="102%" colSpan="3" align="left" className="body"><b>Enter Your ID and Password</b></td>
                
            </tr>
        );
    }
}

export default VelociPrintLoginHeading;
