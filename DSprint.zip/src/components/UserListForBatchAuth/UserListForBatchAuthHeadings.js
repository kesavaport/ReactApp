import React, { Component } from 'react';

class UserListForBatchAuthHeadings extends Component {
    render() {
        return (
            <tr className="HeadTable">
                <td width="15%" colSpan="1" height="21" align="center">Serial No</td>
                <td width="60%" colSpan="1" height="21" align="left">User Name</td>
                <td width="25%" colSpan="1" height="21" align="left">Batch Count</td>
            </tr>
        );
    }
}

export default UserListForBatchAuthHeadings;
