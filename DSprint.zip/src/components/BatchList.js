import React, { Component } from 'react';
import BatchListHeader from './BatchList/BatchListHeader';
import BatchListHeadings from './BatchList/BatchListHeadings';
import BatchListSelection from './BatchList/BatchListSelection';
import BatchInfoButton_Buttons from './BatchInfoButton/BatchInfoButton_Buttons';

import { BrowserRouter, Route, Switch, Link, NavLink } from 'react-router-dom';
class BatchList extends Component {
    render() {
        return (
            <div className="BatchList">
                <br />
                <br />  
                <table cellSpacing="0" cellPadding="0" width="100%" align="center" border="0">
                    <tbody>
                        <BatchListHeader />
                        <tr>
                            <td width="1" bgcolor="#0066ce"><img height="1" src="images/dsPrint/spacer.gif" width="1" /></td>
                            <td width="100%" colSpan="4" >
                                <table cellSpacing="1" cellPadding="1" width="100%" align="center" border="0">
                                    <tbody>
                                        <BatchListHeadings />
                                        <BatchListSelection />
                                        <tr>
                                            <td width="100%" colSpan="4">&nbsp;</td>
                                        </tr>
                                        <tr className="body">
                                            <td width="100%" colSpan="4" height="21" align="center" className="HeadBold">noRecord</td>
                                        </tr>
                                        <tr>
                                            <td width="100%" colSpan="4">&nbsp;</td>
                                        </tr>

                                    </tbody>
                                </table>
                            </td>
                            <td width="1" bgcolor="#0066ce"><img height="1" src="images/dsPrint/spacer.gif" width="1" /></td>
                        </tr>

                        <tr>
                            <td width="1" bgcolor="#0066ce"><img height="1" src="images/dsPrint/spacer.gif" width="1" /></td>
                            <td bgcolor="#0066ce" colSpan="4"><img height="1" src="images/dsPrint/spacer.gif" width="1" /></td>
                            <td width="1" bgcolor="#0066ce"><img height="1" src="images/dsPrint/spacer.gif" width="1" /></td>
                        </tr>
                    </tbody>
                </table>
                <BatchInfoButton_Buttons />
            </div>
        );
    }
}

export default BatchList;
