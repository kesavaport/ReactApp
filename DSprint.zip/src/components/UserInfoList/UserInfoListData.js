import React, { Component } from 'react';

class UserInfoListData extends Component {
    render() {
        return (
            <tr className="body">
                <td width="15%" colSpan="1" height="21" align="center">
                    <input type="radio" name="radioValue" value="" />
                </td>
                <td width="85%" colSpan="1" height="21" align="left">Demo User</td>
            </tr>
        );
    }
}

export default UserInfoListData;
