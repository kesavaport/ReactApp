import React, { Component } from 'react';

class BatchInfoAttributesData extends Component {
  render() {
    return (
        <tr className="body">
        <td width="10%" colSpan="1" height="21" align="left">
            <input type="checkbox" name="chkBox"  />
        </td>
        <td width="30%" colSpan="1" height="21" align="left">BRANCH</td>
        <td width="40%" colSpan="1" height="21" align="left">&nbsp;
        <input type="text" name="attName" size="15" style={{ border: '1 solid' }} className="inps" /></td>
        
    </tr>
    );
  }
}

export default BatchInfoAttributesData;