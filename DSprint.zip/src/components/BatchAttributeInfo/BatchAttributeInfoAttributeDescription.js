import React, { Component } from 'react';

class BatchAttributeInfo_AttributeDescription extends Component {
    render() {
        return (
           


                <tr className="body BatchAttributeInfo_AttributeDescription">
                    <td width="20%" colSpan="1" height="21" align="left">&nbsp;Attribute Description</td>

                    <td width="40%" colSpan="1" height="21" align="left">&nbsp;<textarea name="batchAttributeVO" style={{ border: '1 solid' }} rows="2" cols="25"></textarea></td>
                    <td width="40%" colSpan="1" height="21" align="left"></td>
                </tr>
           
        );
    }
}
export default BatchAttributeInfo_AttributeDescription;