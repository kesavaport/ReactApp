import React, { Component } from 'react';

class BatchAttributeSelect extends Component {
    render() {
        return (
            <tr className="body BatchAttributeSelect" >
                <td width="10%" colSpan="1" height="21" align="center"><input type="radio" name="radioValue" value="" /></td>
                <td width="40%" colSpan="1" height="21" align="left">BRANCH</td>
                <td width="50%" colSpan="1" height="21" align="left">Branch Identifier</td>
            </tr>
        );
    }
}
export default BatchAttributeSelect;