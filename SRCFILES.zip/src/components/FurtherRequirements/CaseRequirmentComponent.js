import React, { Component } from "react";
import { connect } from 'react-redux';


export class CaseRequirmentComponent extends React.Component {
    constructor(props) {
        super(props);
        this.handlerChecked = this.handlerChecked.bind(this);
    }

    handlerChecked(e) {
        //console.log("this.props.geod.caseReq.indexOf(e.target.innerText)--> " +this.props.caseReq.indexOf(e.target.innerText));
        this.props.updateCaseReq(this.props.caseReq.indexOf(e.target.innerText));
    }
    render() {
        console.log(
            "this.props.caseReq", this.props.caseReq
        )
        return (
            <div>
                <div className="card  indigo">
                    <div className="card-content">
                        <span className="card-title white-text text-darken-1">CaseRequirmentComponent</span>
                        <table className="striped white">
                            <thead>
                                <tr>
                                    <th>Item</th>
                                </tr>
                            </thead>

                            <tbody>

                                {this.props.caseReq.map((item, index) => {
                                    return (
                                        <tr key={index} data-key={index}>
                                            <td onClick={this.handlerChecked}>{item}</td>
                                        </tr>
                                    )
                                })}


                            </tbody>
                        </table>

                    </div>

                </div>

            </div>
        )
    }
}

export default CaseRequirmentComponent;
