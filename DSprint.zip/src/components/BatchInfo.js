import React, { Component } from 'react';
import BatchInfoHeader from './BatchInfo/BatchInfoHeader';
import BatchInfoName from './BatchInfo/BatchInfoName';
import BatchInfoDescription from './BatchInfo/BatchInfoDescription';
import BatchInfoButtons from './BatchInfo/BatchInfoButtons';
import BatchInfoAttributesHeadings from './BatchInfo/BatchInfoAttributesHeadings';
import BatchInfoAttributesData from './BatchInfo/BatchInfoAttributesData';
BatchInfoAttributesData
class BatchInfo extends Component {
    render() {
        return (
            <div className="BatchInfo">
                <form>
                    <br />
                    <br />
                    <table cellSpacing="0" cellPadding="0" width="100%" align="center" border="0">
                        <tbody>
                            <BatchInfoHeader />
                            <tr>
                                <td width="1" bgcolor="#0066ce"><img height="1" src="images/dsPrint/spacer.gif" width="1" /></td>
                                <td width="100%" colSpan="3" >
                                    <table cellSpacing="0" cellPadding="0" width="100%" align="center" border="0">
                                        <tbody>
                                            <tr className="body">
                                                <td width="100%" colSpan="3" height="21">&nbsp;</td>
                                            </tr>

                                            <BatchInfoName />

                                            <BatchInfoDescription />
                                            <tr className="body">
                                                <td width="100%" colSpan="3" height="21">&nbsp;</td>
                                            </tr>                                           
                                            <tr className="body">
                                                <td width="100%" colSpan="3" height="23">&nbsp;</td>
                                            </tr>
                                            <BatchInfoAttributesHeadings />
                                            
                                            <BatchInfoAttributesData />
                                            <tr className="body">
                                                <td width="100%" colSpan="3" height="23">&nbsp;</td>
                                            </tr>
                                            <tr className="body">
                                                <td width="100%" bgcolor="#0066ce" colSpan="3"><img height="1" src="images/dsPrint/spacer.gif" width="1" /></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                                <td width="1" bgcolor="#0066ce"><img height="1" src="images/dsPrint/spacer.gif" width="1" /></td>
                            </tr>
                        </tbody>
                    </table>
                </form>
                <BatchInfoButtons />
            </div>
        );
    }
}

export default BatchInfo;
