import React, { Component } from 'react';

class UserBatchAuthBatchName extends Component {
    render() {
        return (
            <tr className="body">
                <td width="30%" colSpan="1" height="21" align="left">&nbsp;Batch Name</td>
                <td width="30%" colSpan="1" height="21" align="left">HRM</td>
                <td width="40%" colSpan="2" height="21" align="left">&nbsp;</td>
            </tr>


        );
    }
}

export default UserBatchAuthBatchName;
