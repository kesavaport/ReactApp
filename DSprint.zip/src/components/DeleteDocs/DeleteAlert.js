import React, { Component } from 'react';

class DeleteAlert extends Component {
    render() {
        return (
            <div className="body">
                <script language="JavaScript">
                    {alert("Deleted Successfully")};
            </script>
            </div>
        );
    }
}

export default DeleteAlert;
