import React, { Component } from 'react';

class UserListForBatchAuthMsg extends Component {
    render() {
        return (
            <tr className="body">
                <td width="100%" colSpan="3" height="21" align="center">NoRecFound</td>
            </tr>
        );
    }
}

export default UserListForBatchAuthMsg;
