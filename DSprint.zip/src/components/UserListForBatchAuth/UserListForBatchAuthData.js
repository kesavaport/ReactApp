import React, { Component } from 'react';
import {  Link, NavLink } from 'react-router-dom';
class UserListForBatchAuthData extends Component {
    render() {
        return (
            <tr className="body">
            
                   <td width="15%" colSpan="1" height="21" align="center">1</td>
                   <td width="60%" colSpan="1" height="21" align="left"><NavLink to="/BatchListForAuthorization">ds1</NavLink></td>
                   <td width="25%" colSpan="1" height="21" align="left">5</td>
               </tr>
        );
    }
}

export default UserListForBatchAuthData;
