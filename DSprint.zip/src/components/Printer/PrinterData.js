import React, { Component } from 'react';

class PrinterData extends Component {
    render() {
        return (
            <table className="card container">
            <tbody>
                <tr>
                    <td width="10%" colSpan="1" height="21" align="center" className="body">
                        <input type="radio" name="radioValue" value="batchAttributeList" />
                    </td>
                    <td width="90%" colSpan="1" height="21" align="left" className="body">HP Laser Jet</td>
                </tr>
                <tr>
                    <td width="10%" colSpan="1" height="21" align="center" className="body">
                        <input type="radio" name="radioValue" value="batchAttributeList" />
                    </td>
                    <td width="90%" colSpan="1" height="21" align="left" className="body">Acrobat PDFWriter</td>
                </tr>
                <tr>
                    <td width="10%" colSpan="1" height="21" align="center" className="body">
                        <input type="radio" name="radioValue" value="batchAttributeList" />
                    </td>
                    <td width="90%" colSpan="1" height="21" align="left" className="body">HP Laser Jet</td>
                </tr>
                <tr>
                    <td width="10%" colSpan="1" height="21" align="center" className="body">
                        <input type="radio" name="radioValue" value="batchAttributeList" />
                    </td>
                    <td width="90%" colSpan="1" height="21" align="left" className="body">Acrobat PDFWriter</td>
                </tr>
            </tbody>    
            </table>
        );
    }
}

export default PrinterData;
