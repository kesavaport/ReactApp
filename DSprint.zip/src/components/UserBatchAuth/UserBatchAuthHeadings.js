import React, { Component } from 'react';

class UserBatchAuthHeadings extends Component {
    render() {
        return (
            <tr className="HeadTable">
                <td width="30%" colSpan="1" height="21" align="left">&nbsp;Serial No.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;AND/OR</td>
                <td width="30%" colSpan="1" height="21" align="left">Attribute Name</td>
                <td width="20%" colSpan="1" height="21" align="left">Operator</td>
                <td width="20%" colSpan="1" height="21" align="left">Filter</td>
            </tr>
        );
    }
}

export default UserBatchAuthHeadings;
