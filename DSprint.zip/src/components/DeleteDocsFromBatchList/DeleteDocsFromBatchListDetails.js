import React, { Component } from 'react';
import {  NavLink } from 'react-router-dom';
class DeleteDocsFromBatchListDetails extends Component {
  render() {
    return (
        <tr className= "body">
        <td width="10%" colSpan="1" height="21" align="center">
            <input type="checkbox" name="docSetPrintChk" value="batchid" />
        </td>
        <td width="30%" colSpan="1" height="21" align="left"><NavLink to="/DeleteDocsFromDocSetList">AWPL</NavLink></td>
        <td width="40%" colSpan="1" height="21" align="left">Automated Workflow Pvt. Ltd.</td>
        <td width="20%" colSpan="1" height="21" align="left">16</td>
    </tr>
    );
  }
}

export default DeleteDocsFromBatchListDetails;