import React, { Component } from 'react';
import { BrowserRouter, Route, Switch, Link, NavLink } from 'react-router-dom';
class BatchAttributeInfoButtons extends Component {
    render() {
        return (
            
                <tr className="body BatchAttributeInfoButtons">
                    <td width="100%" colSpan="3" height="21" align="center">

                        <Link to="/SuccessAttribute"><input type="button" name="ok" value="ok" className="btn btn-primary" height="2px" width="5px" /></Link>&nbsp;
                        <Link to="/BatchAttributeList"><input type="button" name="Cancel" value="Cancel" className="btn btn-primary" /></Link>
                    </td>
                </tr>
            
        );
    }
}
export default BatchAttributeInfoButtons;