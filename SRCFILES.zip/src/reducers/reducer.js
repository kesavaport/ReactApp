import {  combineReducers   } from 'redux';

const input=["201","301","401","New Proposal","NoProposal"];

export const requirements = (state = {title:"hi",caseReq:input,outReq:[]}, action) => {  
    switch (action.type) {
      case 'Update_CaseReq':
        let caseReq = state.caseReq;
        let deletedItem= caseReq.splice(action.deletedIndex,1);
        let outReq = state.outReq || [];
        outReq.push(deletedItem.toString());
        outReq.sort()
          return {
            ...state,
            outReq,
            caseReq
          }
      case 'Update_OutReq':
        let outReq1 = state.outReq;
        let deletedItem1= outReq1.splice(action.deletedIndex,1);
        let caseReq1 = state.caseReq || [];
        caseReq1.push(deletedItem1.toString());
        caseReq1.sort()
          return {
            ...state,
            caseReq1,            
            outReq1
          }
      default:
        return state;
    }
  };
  
  export const reducers = combineReducers({  
    requirements,
  });

  
