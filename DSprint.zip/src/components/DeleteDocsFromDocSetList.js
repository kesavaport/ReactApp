import React, { Component } from 'react';
import DeleteDocsFromDocSetListHeader from './DeleteDocsFromDocSetList/DeleteDocsFromDocSetListHeader';
import DeleteDocsFromDocSetListInfo from './DeleteDocsFromDocSetList/DeleteDocsFromDocSetListInfo';
import DeleteDocsFromDocSetListData from './DeleteDocsFromDocSetList/DeleteDocsFromDocSetListData';
import DeleteDocsFromDocSetListMsg from './DeleteDocsFromDocSetList/DeleteDocsFromDocSetListMsg';
import DeleteDocsFromDocSetListButtons from './DeleteDocsFromDocSetList/DeleteDocsFromDocSetListButtons';

class DeleteDocsFromDocSetList extends Component {
    render() {
        return (
            <div className="DeleteDocsFromDocSetList">
                <form>
                    <br />
                    <br />
                    <table cellSpacing="0" cellPadding="0" width="100%" align="center" border="0">
                        <tbody>
                            <DeleteDocsFromDocSetListHeader />
                            <tr>
                                <td width="1" bgcolor="#0066ce">
                                    <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                                </td>
                                <td width="100%" colSpan="6">
                                    <table cellSpacing="1" cellPadding="1" width="100%" align="center" border="0">
                                        <tbody>
                                            <DeleteDocsFromDocSetListInfo />
                                            
                                            <DeleteDocsFromDocSetListData />
                                            
                                            <DeleteDocsFromDocSetListMsg />
                                            
                                        </tbody>
                                    </table>
                                </td>
                                <td width="1" bgcolor="#0066ce">
                                    <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                                </td>
                            </tr>
                            <tr>
                                <td width="1" bgcolor="#0066ce">
                                    <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                                </td>
                                <td bgcolor="#0066ce" colSpan="6">
                                    <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                                </td>
                                <td width="1" bgcolor="#0066ce">
                                    <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </form>
                <DeleteDocsFromDocSetListButtons />
            </div>
        );
    }
}

export default DeleteDocsFromDocSetList;
