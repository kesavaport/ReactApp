import React, { Component } from 'react';

export class HomeComponent extends Component {

    render() {
       
        return (
            <div style={{textAlign:"center"}}>
                <img src="assets/welcome.png" alt="Welcome Image" style={{margin:"20px auto"}}/>
            </div>
        )
    }
}
//export default HomeComponent;