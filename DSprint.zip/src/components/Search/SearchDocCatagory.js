import React, { Component } from 'react';

class SearchDocCatagory extends Component {
    render() {
        return (
            <tr className="body">
                <td width="40%" colSpan="1" height="21" align="left">&nbsp;&nbsp; Select Document Catagory</td>
                <td width="40%" colSpan="1" height="21" align="left">&nbsp;
            <select className="inps">
                        <option value="selection" disabled hidden>Select</option>
                        <option value="DOCSETID">PRINTED</option>
                        <option value="BATCHDATE">PRINTING</option>
                        <option value="KEYVALUE1">INCOMPLETE</option>
                        <option value="KEYVALUE1">ERROR</option>
            </select>
                </td>
                <td width="40%" colSpan="1" height="21" align="left"></td>
            </tr>


        );
    }
}

export default SearchDocCatagory;
