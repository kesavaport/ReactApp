import React, { Component } from 'react';

class BatchAuthorizationStatusMsg extends Component {
    render() {
        return (
        <tr className="body BatchAuthorizationStatusMsg">
            <td width="100%" colSpan="4" height="21" align="center" className="HeadBold">msg.NoRecFound</td>
        </tr>
                    );
    }
}

export default BatchAuthorizationStatusMsg;
