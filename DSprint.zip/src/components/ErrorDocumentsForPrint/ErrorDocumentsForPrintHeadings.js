import React, { Component } from 'react';

class ErrorDocumentsForPrintHeadings extends Component {
    render() {
        return (
            <tr className="HeadTable">
                <td width="8%" colSpan="1" height="21" align="center">

                    <input type="checkbox" name="chkBox" disabled="disabled" />
                </td>
                <td width="9%" colSpan="1" height="21" align="left">DocID</td>
                <td width="9%" colSpan="1" height="21" align="left">DocSet ID</td>
                <td width="15%" colSpan="1" height="21" align="left">Batch Name</td>
                <td width="15%" colSpan="1" height="21" align="left">Batch Date</td>
                <td width="15%" colSpan="1" height="21" align="left">Attribute1</td>
                <td width="15%" colSpan="1" height="21" align="left">Attribute2</td>
                <td width="15%" colSpan="1" height="21" align="left">LetterType</td>
            </tr>
        );
    }
}

export default ErrorDocumentsForPrintHeadings;
