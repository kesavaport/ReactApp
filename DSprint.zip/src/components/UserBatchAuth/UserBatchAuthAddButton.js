import React, { Component } from 'react';
import { Link } from 'react-router-dom';
class UserBatchAuthAddButton extends Component {
    render() {
        return (
            <tr className="body">
                <td width="100%" colSpan="4" height="23" align="left">
                    &nbsp;<input type="button" name="Add" value="Add" className="btn btn-primary" />
                </td>
            </tr>
        );
    }
}

export default UserBatchAuthAddButton;
