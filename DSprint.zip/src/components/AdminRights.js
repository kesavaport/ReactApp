import React, { Component } from 'react';
import AdminRightsFrame from './AdminRights/AdminRightsFrame';
class AdminRights extends Component {
    render() {
        return (
            <div className="AdminRights">
                <AdminRightsFrame />

            </div>
                    );
    }
}

export default AdminRights;
