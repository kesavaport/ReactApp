import React, { Component } from 'react';

class ErrorsForRouterData extends Component {
    render() {
        return (
            <tr className="body">
                <td width="5%" colSpan="1" height="21" align="center">
                    <input type="checkbox" name="docSetPrintChk" value="" />
                </td>
                <td width="17%" colSpan="1" height="21" align="left">NB</td>
                <td width="12%" colSpan="1" height="21" align="left">2017/12/23</td>
                <td width="20%" colSpan="1" height="21" align="left">a@a.com</td>
                <td width="13%" colSpan="1" height="21" align="left"></td>
                <td width="33%" colSpan="1" height="21" align="left">testing error22</td>
            </tr>

        );
    }
}

export default ErrorsForRouterData;
