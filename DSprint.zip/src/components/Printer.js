import React, { Component } from 'react';
import VPLoggedPage from './VPLoggedPage';
import PrinterHeader from './Printer/PrinterHeader';
import PrinterButton from './Printer/PrinterButton';
import PrinterData from './Printer/PrinterData';

class Printer extends Component {
    render() {
        return (
            <div  className="container3">
            <center>
                <form>
                    <br />
                    <br />
                    <table cellSpacing="0" cellPadding="0" width="100%" align="center" border="0">
                        <tbody>
                            <PrinterHeader />
                            <tr>
                                <td width="1" bgcolor="#0066ce">
                                    <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                                </td>
                                <td width="100%" colSpan="3">
                                    <br />
                                    <table cellSpacing="1" cellPadding="1" width="100%" align="center" border="0">
                                        <tbody>
                                          
                                            <PrinterData />
                                            
                                            <tr>
                                                <td width="100%" colSpan="3">&nbsp;</td>
                                            </tr>
                                            <PrinterButton />
                                        </tbody>
                                    </table>
                                </td>
                                <td width="1" bgcolor="#0066ce">
                                    <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                                </td>
                            </tr>
                            <tr>
                                <td width="1" bgcolor="#0066ce">
                                    <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                                </td>
                                <td bgcolor="#0066ce" colSpan="3">
                                    <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                                </td>
                                <td width="1" bgcolor="#0066ce">
                                    <img height="1" src="images/dsPrint/spacer.gif" width="1" />
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </form>
                </center>
            </div>
        );
    }
}

export default Printer;
