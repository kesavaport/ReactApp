import React, {Component} from "react";

 export class OutstandingReqComponent extends React.Component{
    constructor(props){
        super(props);
       this.handlerChecked=this.handlerChecked.bind(this);
      }    
     
      handlerChecked(e){
          console.log("index-->" + this.props.outReq.indexOf(e.target.innerText));
       this.props.updateOutReq(this.props.outReq.indexOf(e.target.innerText));
      }

    render(){
        return(
            <div>
                <div className="card indigo">
                <div className="card-content">
                    <span className="card-title white-text text-darken-1">OutstandingReqComponent</span>
                    <table className="striped white">
                        <thead>
                        <tr>
                            <th>Item</th>             
                        </tr>
                        </thead>

                        <tbody>
                        
                            {this.props.outReq.map((item,index)=> {
                                return(
                                    <tr key={index} data-key={index}>
                                        <td onClick={this.handlerChecked}>{item}</td>
                                    </tr>
                                )
                            })}         
                        
                        
                        </tbody>
                    </table>            
                </div>
                        
                </div>
            </div>
        )
    }
}

export default OutstandingReqComponent;
  